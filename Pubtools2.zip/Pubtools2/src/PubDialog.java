
// This class defines a dialog that can be closed by pressing the escape key.
// All that this code does is to make the escape key close the dialog.

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.KeyStroke;


public class PubDialog extends JDialog
{
	private static final long serialVersionUID = 830041970343253599L;
	public PubDialog()
	{
		// Close the dialog if the user presses escape
		Action escAction = new AbstractAction()
		{
			private static final long serialVersionUID = -5854923372975204892L;
			public void actionPerformed(ActionEvent ae) { dispose(); }
		};
		this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "esc");
		this.getRootPane().getActionMap().put("esc", escAction);
	}
}