import java.util.ArrayList;

public class Pub implements Cloneable
{
	public enum CompareBy {
		// Use the objects normal method
		COMPARETO { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			return o1.compareTo(o2);
		} },
		
		NAME { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			return ((BeerStock)o1).getBeer().getName().compareTo(((BeerStock)o2).getBeer().getName());
		} },
		
		// Compare by stock after
		STOCKAFTER { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			int r1 = ((BeerStock)o1).getStockAfter();
			int r2 = ((BeerStock)o2).getStockAfter();
			if(r1 > r2)
				return 1;
			if(r1 < r2)
				return -1;
			return 0;
		} },
		
		// Compare by stock difference
		STOCKDIFF { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			int r1 = ((BeerStock)o1).stockDiff();
			int r2 = ((BeerStock)o2).stockDiff();
			if(r1 > r2)
				return 1;
			if(r1 < r2)
				return -1;
			return 0;
		} },
		
		// Compare by percentage of the beer sold
		PERCENTAGESOLD { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			double r1 = ((BeerStock)o1).percentageSold();
			double r2 = ((BeerStock)o2).percentageSold();
			if(r1 == -1.0 && r2 == -1.0)
				return 0;
			else if(r1 == -1.0)
				return -1;
			else if(r2 == -1.0)
				return 1;
			if(r1 > r2)
				return 1;
			if(r1 < r2)
				return -1;
			return 0;
		} },
		
		//
		MONEYMADE { @Override
		<T extends Comparable<? super T>> int compareBy(T o1, T o2)
		{
			double r1 = ((BeerStock)o1).moneyMade();
			double r2 = ((BeerStock)o2).moneyMade();
			if(r1 > r2)
				return 1;
			if(r1 < r2)
				return -1;
			return 0;
		} };
		
		
		// Run the function represented by this constant
		abstract <T extends Comparable<? super T>> int compareBy(T x, T y);
	}
	
	
	
	public Pub()
	{
		year  = 2010;
		month = 05;
		day   = 01;
		name  = "Delta 10";
		description = "Delta 10 går på";
	}
	
	public void setDate(int y, int m, int d)			{ year = y; month = m; day = d; }
	public void setName(String n)						{ name = n; }
	public void setDescription(String d)				{ description = d; }
	public int getYear()								{ return year; }
	public int getMonth()								{ return month; }
	public int getDay()									{ return day; }
	public int size()									{ return beerstock.size(); }
	public String getName()								{ return name; }
	public String getDescription()						{ return description; }
	
	
	public double moneyMade(int i)						{ return beerstock.get(i).moneyMade(); }
	public double percentageSold(int i)					{ return beerstock.get(i).percentageSold(); }
	public int stockDiff(int i)							{ return beerstock.get(i).stockDiff(); }
	public Beer getBeer(int i)							{ return beerstock.get(i).getBeer(); }
	public int getStockBefore(int i)					{ return beerstock.get(i).getStockBefore(); }
	public int getStockAfter(int i)						{ return beerstock.get(i).getStockAfter(); }
	public int getToFridge(int i)						{ return beerstock.get(i).getToFridge(); }
	public int getFromFridge(int i)						{ return beerstock.get(i).getFromFridge(); }
	public BeerCategory getCategory(int i)				{ return beerstock.get(i).getCategory(); }
	public BeerStock getBeerStock(int i)				{ return beerstock.get(i); }
	public ArrayList<BeerStock> getBeerStock()			{ return beerstock; }
	public ArrayList<BeerCategory> getBeerCategory()	{ return beercat; }
	
	public void remove(int index)						{ beerstock.remove(index); }
	public void setBeerStock(int i, BeerStock s)		{ beerstock.set(i, s); }
	
	public void add(BeerStock a)
	{
		beerstock.add(a);
		for(int i = 0; i < beercat.size(); i++)
			if(a.getCategory().getOrder() == beercat.get(i).getOrder())
				return;
		beercat.add(a.getCategory());
		sortCategories();
	}
	
	
	
	public int getIndex(String beername)
	{
		for(int i = 0; i < beerstock.size(); i++)
			if(beerstock.get(i).getBeer().getName().equals(beername))
				return i;
		return -1;
	}
	
	public void sortCategories()
	{
		sort(beercat, CompareBy.COMPARETO);	
	}
	
	public void sort()
	{
		sort(beerstock, CompareBy.COMPARETO);
	}
	
	public void sort(CompareBy sortmethod)
	{
		sort(beerstock, sortmethod);
	}
	
	public <T extends Comparable<? super T>> void sort(ArrayList<T> arr, CompareBy sortmethod)
	{
		if(arr.size() <= 1)
			return;
		
		// Bubblesort
		boolean onceMore = true;
		while(onceMore)
		{
			onceMore = false;
			for(int i = 0; i < arr.size() - 1; i++)
			{
				if(sortmethod.compareBy(arr.get(i), arr.get(i + 1)) == 1)
				{
					T temp = arr.get(i);
					arr.set(i, arr.get(i + 1));
					arr.set(i + 1, temp);
					onceMore = true;
				}
			}
		}
	}
	
	
	@Override
	public Pub clone()
	{
		try
		{
			Pub clone = (Pub) super.clone();
//			clone.beerstock = new ArrayList<BeerStock> (this.beerstock.size());
//			clone.beercat   = new ArrayList<BeerCategory>(this.beercat.size());
			clone.beerstock = (ArrayList<BeerStock>) this.beerstock.clone();
			clone.beercat   = (ArrayList<BeerCategory>) this.beercat.clone();
			for(int i = 0; i < beerstock.size(); i++)
				clone.beerstock.set(i, this.beerstock.get(i).clone());
			
			for(int i = 0; i < beercat.size(); i++)
				clone.beercat.set(i, this.beercat.get(i).clone());
			
			return clone;
		}
		catch(CloneNotSupportedException e) { }
		return null;
	}
	
	public boolean equals(Object o)
	{
		if(o == null || (!(o instanceof Pub)))
			return false;
		Pub p = (Pub)o;
		if((p.year == this.year) && (p.month == this.month) && (p.day == this.day) && (p.name.equals(this.name)) && 
			(p.description.equals(this.description)) && (p.beerstock.size() == this.beerstock.size()) && 
			(p.beercat.size() == this.beercat.size()))
		{
			for(int i = 0; i < beerstock.size(); i++)
				if(!p.beerstock.get(i).equals(this.beerstock.get(i)))
					return false;
			for(int i = 0; i < beercat.size(); i++)
				if(!p.beercat.get(i).equals(this.beercat.get(i)))
					return false;
			return true;
		}
		return false;
	}
	
	private int year;
	private int month;
	private int day;
	private String name;
	private String description;
	private ArrayList<BeerStock> beerstock  = new ArrayList<BeerStock>();
	private ArrayList<BeerCategory> beercat = new ArrayList<BeerCategory>();
}
