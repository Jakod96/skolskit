import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;



public class PubIO
{
	private static final String AGENTURL = "http://agent.nocrew.org/xml/cached/products.xml";
	private static final String BOLAGETURLBEG = "http://www.systembolaget.se/Ajax.aspx?varuNr=";
	private static final String BOLAGETURLEND = "&action=modaldialog&actiontype=butikdryck";
	private static final String SYSTEMETURL = "http://www.systembolaget.se/Sok-dryck/Dryck/?varuNr=";
	private static final boolean WARN_OF_TOO_LOW_PRICE = true;
	private static final int MIN_PRICE = 20;
	private static final double MIN_ABV_FOR_MARKUP = 3.5;
	private static double inventorybuysum = 0.0;
	private static double inventorysellsum = 0.0;
	private static final String[] XMLCHILDNAMES = { "name", "type", "country", "abv", "volume", "id", "buyprice", 
												  "sellprice", "category", "stockbefore", "stockafter" };
	public static final String[] STANDARDCHILDVALUES = 
												{ "", "", "", "-1.0", "-1", "-1", "-1.0", "-1", "-1", "-1", "-1" };
	
	private static final String[][] STORES = {
		{ "Karl Johansgatan 85", "AB"},
		{ "Gårda, Åvägen 42", "IF"},
		{ "Kapellplatsen 4", "KP"},
		{ "Nordstan, Lilla Klädpressaregatan", "NS"}
	};
	
	
	
	public static void exportPubXML(Pub pub, File file) throws IOException
	{
		pub.sort();
		Document data = PubIO.createXMLFile(pub);
		
		FileWriter fw = new FileWriter(file);
		XMLOutputter b = new XMLOutputter();
		b.setFormat(Format.getPrettyFormat());
		b.output(data, fw);
		fw.close();
	}
	
	// Based on http://www.javaworld.com/javatips/jw-javatip19.html
	private static void downloadFile(String urlToGet, File file) throws IOException 
	{
		InputStream is = new URL(urlToGet).openStream();
		FileOutputStream fos = new FileOutputStream(file);
		
		int oneChar;
		while((oneChar = is.read()) != -1)
			fos.write(oneChar);
		is.close();
		fos.close();
	}
	
	public static void removeFile(String filename) throws IllegalArgumentException
	{
		File file = new File(filename);
		
		// Make sure the file or directory exists and isn't write protected
		if(!file.canWrite())
			throw new IllegalArgumentException("Cannot delete write protected file: " + filename);
		
		// Attempt to delete it
		boolean success = file.delete();
		if(!success)
			throw new IllegalArgumentException("Delete: deletion failed");
	}
	
	
	
	
	
	
	private static String makeToolTip(Store[] stores, int req)
	{
		String output = "";
		if(stores == null)
			return "";
		
		for(int i = 0; i < stores.length; i++)
		{
			String stockenough = "stockenough";
			String storenick = stores[i].getNick(); 
			if(stores[i].getAmount() < req)
			{														// The stock isn't enough. Make the link use
				stockenough = "stocknotenough";						// the "stocknotenough" class and strike it.
				storenick = "<strike>" + storenick + "</strike>";
			}
			output += makeToolTip(stores[i].getAdress(), "In stock: " + stores[i].getAmount(), stockenough, storenick);
			output += "&nbsp;";
		}
					
		return output;
	}
	
	
	private static String makeToolTip(String header, String body, String aclass, String atxt)
	{
		return "<a href=\"#\" class=\"" + aclass + "\" onmouseover=\"showToolTip('"  + 
				header + "','" + body + "',event);\" onmouseout=\"hideToolTip();\">" + 
				atxt + "</a>";
	}
	
	
	
	private static <E> void swap(E[] list, int i, int j)
	{
		E temp = list[i];
		list[i] = list[j];
		list[j] = temp;
	}
	
	public static String trimDecimals(double in)
	{
		String w = "" + in;
		int pos = w.indexOf('.');
		if(pos == -1)
			return w;
		w += "00";
		String d = w.substring(pos);
		w = w.substring(0, pos);
		if(d.length() > 3)
			d = d.substring(0, 3);
		return w + d;
	}
	
	
	public static void exportPubStatistics(Pub pub, File file, boolean dldata) throws IOException, JDOMException
	{
		return;
	}
	
	
	
	
	
	public static Store[] getStoreData(int id) throws IOException, JDOMException
	{
		if(id < 0)
			return null;
		
		File file = new File("agent.xml");
		if(!file.exists())
			downloadFile(AGENTURL, file);

		Store[] stores = getAgentStores(id, "agent.xml");
		
		
		// If the agent doesn't track this beer, then stores is null. Try to download the data from 
		// Systembolaget's website. First we want to download data from the first Systembolaget store in 
		// our STORES array ("Awesomebolaget"). We assume that we will always shop in that store, so if 
		// they have enough bottles, we are satisfied with that and return only the data from Awesomebolaget.
		// However, if they don't have any bottles (stores equals "?"), or don't have enough bottles
		// (stores contains the HTML-tag "<strike>"), then we will continue to search through the rest 
		// of the Systembolaget stores in our STORES array and return the data from them as well. 
		if(stores == null)											// The agent doesn't track this beer
			stores = getSystemetStores(id);							// Download data from Awesomebolaget
		
		return stores;
	}
		
	public static Store[] getSystemetStores(int id) throws IOException
	{
		// Download the HTML file from Systembolaget.
		File file = new File("bolaget.html");
		downloadFile(BOLAGETURLBEG + id + BOLAGETURLEND, file);
		
		String data = "";
		Scanner in  = new Scanner(new FileReader(file));
		
		// Read the whole file
		while(in.hasNextLine())
			data += in.nextLine();
		in.close();
		
		// Discard uninteresting data
		int pos0, pos1;
		pos0 = data.indexOf("<div id=\"byName\" name=\"byName\">");
		if(pos0 == -1)
			return null;
		
		// Go down to the first store in Göteborg
		data = data.substring(pos0);
		pos0 = data.indexOf("<strong>Göteborg</strong><br />");
		if(pos0 == -1)
			return null;
		
		// Only keep the data that's between the first store in Gothenburg and the rest of the stores that 
		// is in a city beginning with "G".
		data = data.substring(pos0, data.indexOf("</fieldset>", pos0));
		
		
		
		// Count how many stores there are in Göteborg with bottles of the current beer.
		// This function outputs an array with Stores, so we need to know how many elements the array shall have. 
		int gbgstores = 0;
		pos0 = 0;
		while(pos0 != -1)
		{
			gbgstores++;
			pos0 = data.indexOf("<strong>Göteborg</strong><br />", pos0 + 1);
		}
		
		Store[] stores = new Store[gbgstores];
		String sl = "<span class=\"storeLocation\">";
		String am = "<td class=\"amount\">";
		for(int i = 0; i < gbgstores; i++)
		{
			pos0 = data.indexOf(sl) + sl.length();
			pos1 = data.indexOf("</span>", pos0);
			
			String name = data.substring(pos0, pos1);		// Extract the address of the store
			data = data.substring(pos0);					// Remove everything before the current store in the data
			
			name = name.replace("  ", " ");					// Replace double spaces with just one space
			if(name.indexOf(" ") == 0)						// If the name begins with a space...
				name = name.substring(1);					// ... then remove the first char in the name.
			if(name.charAt(name.length() - 1) == ' ')		// If the name ends with a space...
				name = name.substring(0, name.length() - 2);// ... then remove the last char in the name.
			
			
			pos0 = data.indexOf(am) + am.length();
			pos1 = data.indexOf(" st", pos0);
			
			String amount = data.substring(pos0, pos1).replace(" ", "");	// Extract how many bottles the store has.
			amount = amount.replace("\t", "");
			stores[i] = new Store(name, getStoreNick(name, i), Integer.parseInt(amount));
		}
		sortStores(stores);
		
		return stores;
	}
	
	public static Store[] getAgentStores(int id, String filename) throws IOException, JDOMException
	{
		Document d = new SAXBuilder().build(filename);
		
		Element beer = null;
		List<Element> products = d.getRootElement().getChildren("product");
		// Go through all the beers in the agent XML-file
		for(int i = 0; i < products.size(); i++)
		{
			// All beers seem to have two IDs in the Agent XML-file, one internal and one from Systembolaget.
			// Remove all IDs that aren't from Systembolaget.
			while(!products.get(i).getChild("id").getAttributeValue("key").equals("systembolaget"))
				products.get(i).removeChild("id");
			String sysid = products.get(i).getChild("id").getValue();		// The Systembolaget ID
			
			// sysid is the full Systembolaget ID. Ours have less digits, ie if the full Systembolaget ID is
			// 150203, we have 1502. Thus, we compare by checking if the full Systembolaget ID starts with ours:
			if(sysid.startsWith("" + id))
			{
				beer = products.get(i);		// We have a match! This is the beer we're looking for!
				break;						// Stop looping.
			}
		}
		if(beer == null)					// No beer found, return null
			return null;
		
		// The Agent doesn't update this beer any more, it's too old.
		if(beer.getChild("collect-status").getValue().equals("false"))
			return null;
		
		List<Element> xmlstores = beer.getChild("inventory").getChildren();
		
		ArrayList<Store> stores = new ArrayList<Store>();
		
		// Loop through all the stores that has the beer we are looking for. Skip over those not in Göteborg,
		// since we're not interested in them. The final STORES has a list of store names and their nicknames,
		// so search through that list and see if we can give any of the stores a nickname. Those that have no
		// nicknames are named "B*", where * is a number. When we have a store in town, extract the information
		// we want from the "stores" variable.
		for(int i = 0; i < xmlstores.size(); i++)
		{
			// Get the attribute "address" from the XML data:
			String address = xmlstores.get(i).getAttributeValue("address");
			if(address.contains("Göteborg"))			// Don't bother with places not in Göteborg
			{
				String storenick = getStoreNick(address, stores.size());
				
				// Extract the information we want:
				int amount = Integer.parseInt(xmlstores.get(i).getValue());
				stores.add(new Store(address, storenick, amount));
			}
		}
		if(stores.size() == 0)
			return null;
		
		Store[] output = new Store[stores.size()];
		for(int i = 0; i < stores.size(); i++)
			output[i] = stores.get(i);
		
		sortStores(output);
		return output;
	}
	
	
	private static void sortStores(Store[] stores)
	{
		// Sort the array of stores in the order STORES is in, ie if the array of stores contains the first 
		// and third element in STORES, then put those elements at the beginning of the array.
		int index = 0;
		for(int i = 0; i < STORES.length; i++)
		{
			for(int j = index; j < stores.length; j++)
			{
				if(stores[j].getAdress().contains(STORES[i][0]))
				{
					swap(stores, index, j);
					index++;
					break;
				}
			}
		}
	}
	
	
	private static String getStoreNick(String address, int num)
	{
		String storenick = "";					// The short hand nickname of the store
		for(int i = 0; i < STORES.length; i++)	// Check if the store has a nickname
		{
			if(address.contains(STORES[i][0]))	// It does, use the nickname in STORES[k][1].
			{
				storenick = STORES[i][1];
				break;
			}
		}
		if(storenick.equals(""))	// The store doesn't exist in our predefined list, just add the number
			storenick = "B" + num;
		
		return storenick;
	}
	
	
	public static void exportShopList(Pub pub, File file) throws IOException, JDOMException
	{
		// There are two arrays, mode and tables. The first one contain the way the pub should be sorted by, the second
		// will contain the HTML table with the relevant data.
		pub.sort(Pub.CompareBy.NAME);
		
		String html = getHtmlHeader("Shop List");
		html += "<table border=\"1px\"><tr><td>A = Name</td><td>B = In Stock</td><td>C = Sold</td></tr>\n<tr>" +
				"<td>D = Price</td><td>E = Min amount</td><td>F = Wish amount</td></tr>\n<tr><td>G = Min sum</td>" +
				"<td>H = Wish sum</td><td id=\"btn\">&nbsp;</td></tr></table>\n\n" +
				"<table class=\"sortable\" id=\"percentagesold\">\n<tr><th>A</th><th>B</th><th>C</th><th>D</th><th>E" +
				"</th><th>F</th><th>G</th><th>H</th><th>I</th></tr>\n\n\n";
		
		double  minbuysum = 0.0;
		double wishbuysum = 0.0;
		for(int i = 0; i < pub.size(); i++)
		{
			String td = null;
			if(i % 2 == 0)
				td = "class=\"e\">";
			else
				td = "class=\"u\">";
			html += "<tr><td " + td;
			
			BeerStock bs = pub.getBeerStock(i);
			Beer b = pub.getBeer(i);
			
			minbuysum  += b.getBuyprice() * bs.getMinAmount();
			wishbuysum += b.getBuyprice() * bs.getWishAmount();
			
			html += "<a href=\"" + SYSTEMETURL + b.getId() + "\">" + rmSp(b.getName()) + "</a></td><td " + td + 
				bs.getStockAfter() + "</td><td " + td + bs.stockDiff() + 
				"</td><td id=\"price"   + i + "\" " + td + b.getBuyprice() + "</td><td id=\"minamount" + i + "\" " + td +
				bs.getMinAmount() + "</td><td id=\"wishamount" + i + "\" " + td + bs.getWishAmount() +
				"</td><td id=\"minsum"  + i + "\" " + td + trimDecimals(bs.getMinAmount()  * b.getBuyprice()) + 
				"</td><td id=\"wishsum" + i + "\" " + td + trimDecimals(bs.getWishAmount() * b.getBuyprice()) + 
				"</td><td id=\"stores"  + i + "\" " + td + makeToolTip(b.getStores(), bs.getMinAmount())+ "</td></tr>\n";
		}
		
		String a = "<td>&nbsp;</td>";
		html += "<tr>" + a + a + a + a + a + a + "<th id=\"minsum\">" + trimDecimals(minbuysum) + 
				"</th><th id=\"wishsum\">" + trimDecimals(wishbuysum) + "</th></tr></table>\n\n<br /><br /><br />\n\n";
		
		html += GetHeaderFooter.PUBLIST.getOutput(1);
		
		
		writeToFile(file, html);
	}
	
	

	public static void exportWikiTable(Pub pub, File file) throws IOException
	{
		exportPub(pub, file, GetList.WIKI, GetHeaderFooter.WIKI);
	}

	public static void exportPubList(Pub pub, File file) throws IOException
	{
		exportPub(pub, file, GetList.PUBLIST, GetHeaderFooter.PUBLIST);
	}
	
	public static void exportInventory(Pub pub, File file) throws IOException
	{
		inventorybuysum = 0.0;
		inventorysellsum = 0.0;
		
		Pub pubcopy = pub.clone();
		for(int i = 0; i < pubcopy.size(); i++)
			if(pubcopy.getBeerStock(i).getStockAfter() == 0)// If there are no beers left, then remove it.
				pubcopy.remove(i--);						// Remove beer, then decrement (otherwise we'd skip one beer)
		
		exportPub(pubcopy, file, GetList.INVENTORY, GetHeaderFooter.PUBLIST);
	}
	
	public static void exportPub(Pub pub, File file, GetList l, GetHeaderFooter hf) throws IOException
	{
		String output = hf.getOutput(0);
		output += createList(pub, l);
		if(l == GetList.INVENTORY)
			output += "<tr><td colspan=\"6\"><b>Total cost: " + trimDecimals(inventorybuysum) + " kr<br />\n" +
					  "Total income when sold: " + trimDecimals(inventorysellsum) + " kr<br />\n" +
					  "Total money made: " + trimDecimals(inventorysellsum - inventorybuysum) + " kr</b></td></tr>";
		output += "</table>";
		output += hf.getOutput(1);
		writeToFile(file, output);
	}
	
	public static void writeToFile(File file, String s) throws IOException
	{
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF16"));
		out.write(s);
		out.close();
	}
	
	public static String createList(Pub pub, GetList type)
	{
		pub.sort();
		BeerCategory lastCat = pub.getCategory(0);
		String output = type.getOutput(-1, lastCat.getName());
		
		for(int i = 0, j = 0; i < pub.size(); i++)
		{
			if(pub.getBeerStock(i).getStockBefore() != 0)
			{
				if(!pub.getCategory(i).equals(lastCat))
				{
					lastCat = pub.getCategory(i);
					output += type.getOutput(-1, lastCat.getName());
				}
				output += type.getOutput(j, pub.getBeerStock(i));
				j++;
			}
		}
		return output;
	}
	
	
	public enum GetList
	{
		WIKI { String getOutput(int i, Object in)
		{
            String a = "|";
            String n = "\n";
			if(i == -1) {
                return a + "-" + n + "!colspan= \"7\"|" + (String)in + n;
            }
            Beer beer = ((BeerStock)in).getBeer();
            int price = beer.getSellprice();
			if(WARN_OF_TOO_LOW_PRICE && price < MIN_PRICE && beer.getAbv() > MIN_ABV_FOR_MARKUP)
				if(JOptionPane.showConfirmDialog(null,
						beer.getName() + " costs less than " + MIN_PRICE + " kr. " + 
						"Change to " + MIN_PRICE + " kr in the output?",
						"Display higher price?", JOptionPane.YES_NO_OPTION) == 0) // yes
					price = MIN_PRICE;
			
			return  a + "-" + n + a + i + "." + n + a + beer.getName() + n + a + beer.getType() + n + a + beer.getCountry() + n+ a +
			beer.getAbv() + "%" + n + a + beer.getVolume() + " ml" + n + a + price + " kr" + "\n";
		} },
		
		PUBLIST { String getOutput(int i, Object in)
		{
			if(i == -1)
				return "<tr><th class=\"deltaheader\" colspan=\"7\" align=\"left\">" + rmSp((String)in) + "</th></tr>\n";
			
			Beer beer = ((BeerStock)in).getBeer();
			int price = beer.getSellprice();
			if(WARN_OF_TOO_LOW_PRICE && price < MIN_PRICE && beer.getAbv() > MIN_ABV_FOR_MARKUP)
				if(JOptionPane.showConfirmDialog(null,
						beer.getName() + " costs less than " + MIN_PRICE + " kr. " + 
						"Change to " + MIN_PRICE + " kr in the output?",
						"Display higher price?", JOptionPane.YES_NO_OPTION) == 0) // yes
					price = MIN_PRICE;
			
			String output = "<tr class=\"";
			String td;
			if(i % 2 == 0)
				td = "e\">";
			else
				td = "u\">";
			output += td;
			return output + 
			     "\n<td class=\"number "+td+i                   +".</td>\n<td class=\"name "   +td+rmSp(beer.getName())   +
			"</td>\n<td class=\"type "  +td+rmSp(beer.getType())+ "</td>\n<td class=\"country "+td+rmSp(beer.getCountry())+ 
			"</td>\n<td class=\"abv "   +td+beer.getAbv()       +"%</td>\n<td class=\"volume " +td+beer.getVolume() + "&nbsp;ml" + 
			"</td>\n<td class=\"price " +td+price               + "&nbsp;kr</td>\n</tr>\n"; 
		} },
		
		INVENTORY { String getOutput(int i, Object in)
		{
			if(i == -1)
				return "<tr><th colspan=\"6\" align=\"left\">" + rmSp((String)in) + "</th></tr>\n";
			
			BeerStock bs = (BeerStock)in;
			Beer beer = bs.getBeer();
			String output;
			if(i % 2 == 0)
				output = "<tr class=\"e\">";
			else
				output = "<tr class=\"u\">";
			
			
			inventorybuysum  += bs.getStockAfter() * beer.getBuyprice();
			inventorysellsum += bs.getStockAfter() * beer.getSellprice();
			return output + 
			      "\n<td class=\"number\">"  +i                   +
			".</td>\n<td class=\"name\">"    +rmSp(beer.getName())+
			 "</td>\n<td class=\"type\">"    +rmSp(beer.getType())+
			 "</td>\n<td class=\"amount\">"  +bs.getStockAfter()  + "&nbsp;st"+
			 "</td>\n<td class=\"buyprice\">"+beer.getBuyprice()  + "&nbsp;kr"+
			 "</td>\n<td class=\"sum\">"     +trimDecimals(bs.getStockAfter() * beer.getBuyprice())+
			 "&nbsp;kr</td>\n</tr>\n"; 
		} };
		
		
		// Run the function represented by this constant
		abstract String getOutput(int i, Object o);
	}
	
	
	public enum GetHeaderFooter
	{
		WIKI { String getOutput(int in)
		{
			if(in == 0)
				return "{| class=\"wikitable\"\n";
			return "";
		} },
		
		PUBLIST { String getOutput(int in)
		{
			if(in == 0)
				return getHtmlHeader("Øhllista") + "<table>";
			return "\n\n<div class=\"footer\"></div>\n\n</body>\n</html>\n";
		} };
		
		
		// Run the function represented by this constant
		abstract String getOutput(int in);
	}
	
	
	private static String getHtmlHeader(String pagetitle)
	{
		return "<html>\n<header>\n<title>" + pagetitle + "</title>\n<link rel=\"stylesheet\" " +
				"type=\"text/css\" href=\"stylesheet.css\" />\n" +
				"<script src=\"sorttable.js\"></script>\n" +
				"<script type=\"text/javascript\" src=\"tooltip.js\"></script>\n" + 
				"</header>\n\n<body>\n<div id=\"toolTip\"> </div>\n\n";
	}
	
	
	
	private static String rmSp(String s)
	{
		return s.replaceAll(" ", "&nbsp;");
	}
	
	
	
	public static Pub readXMLFile(File file) throws IOException, JDOMException
	{
		Pub pub = new Pub();
		Document d = new SAXBuilder().build(file);
		
		try
		{
			List<Element> header = d.getRootElement().getChild("header").getChildren();
			pub.setName(header.get(0).getText());
			pub.setDate(Integer.parseInt(header.get(1).getText()),
						Integer.parseInt(header.get(2).getText()), 
						Integer.parseInt(header.get(3).getText()));
			pub.setDescription(header.get(4).getText());
		}
		catch(Exception e) { }
		
		
		List<Element> categories = d.getRootElement().getChild("categories").getChildren();
		ArrayList<BeerCategory> cats = new ArrayList<BeerCategory>(categories.size());
		
		for(int i = 0; i < categories.size(); i++)
			cats.add(new BeerCategory(categories.get(i).getText(), i));
		
		List<Element> beers = d.getRootElement().getChild("beers").getChildren();
		for(int i = 0; i < beers.size(); i++)
		{
			Element beer  = beers.get(i);
			String[] strs = STANDARDCHILDVALUES.clone();
			
			for(int j = 0; j < XMLCHILDNAMES.length; j++)
			{
				Element child = beer.getChild(XMLCHILDNAMES[j]);
				if(child != null)
				{
					String temp = child.getText();
					if(!temp.equals(""))
						strs[j] = temp;
				}
			}
			
			pub.add(new BeerStock(
					new Beer(strs[0], strs[1], strs[2], Double.parseDouble(strs[3]), Integer.parseInt(strs[4]), 
							Integer.parseInt(strs[5]), Double.parseDouble(strs[6]), Integer.parseInt(strs[7])), 
					cats.get(Integer.parseInt(strs[8])), Integer.parseInt(strs[9]), Integer.parseInt(strs[10])));
		}
		
		return pub;
	}
	
	
	public static Document createXMLFile(Pub pub)
	{
		Document d = new Document();
		try
		{
			Element header =  new Element("header");
			header.addContent(new Element("name")       .addContent(pub.getName()));
			header.addContent(new Element("year")       .addContent(pub.getYear() +""));
			header.addContent(new Element("month")      .addContent(pub.getMonth()+""));
			header.addContent(new Element("day")        .addContent(pub.getDay()  +""));
			header.addContent(new Element("description").addContent(pub.getDescription()));
			
			
			ArrayList<BeerStock>  beerstock = pub.getBeerStock();
			ArrayList<BeerCategory> beercat = new ArrayList<BeerCategory>();
			
			Element beers = new Element("beers");
			
			for(int i = 0; i < beerstock.size(); i++)
			{
				Element elem = new Element("beer");
				BeerStock bs = beerstock.get(i);
				Beer b = bs.getBeer();
				
				// The array below must have the length of XMLCHILDNAMES.
				String[] values = { "" + b.getName(), "" + b.getType(), "" + b.getCountry(), "" + b.getAbv(), 
									"" + b.getVolume(), "" + b.getId(), "" + b.getBuyprice(), "" + b.getSellprice(), 
									"" + bs.getCategory().getOrder(), "" + bs.getStockBefore(), "" + bs.getStockAfter()
								  };
				
				// Add the data to the XML element.
				for(int j = 0; j < XMLCHILDNAMES.length; j++)
					addXMLContent(elem, j, values[j]);
				
				// See if we are to add the category to the category list:
				BeerCategory c = bs.getCategory();
				String temp = "" + c.getOrder();
				if(!temp.equals("") && !temp.equals(STANDARDCHILDVALUES[8]))
				{
					boolean add = true;
					for(int j = 0; j < beercat.size() && add; j++)
						if(beercat.get(j).getOrder() == c.getOrder())
							add = false;
					if(add)
						beercat.add(c);
				}
				
				beers.addContent(elem);
			}
			
			
			Element categories = new Element("categories");
			categories.setAttribute("amount", "" + beercat.size());
			
			for(int i = 0; i < beercat.size(); i++)
			{
				Element temp = new Element("category");
				temp.setAttribute("id", "" + i);
				temp.setText(beercat.get(i).getName());
				
				categories.addContent(temp);
			}
			
			Element root = new Element("pub");
			root.addContent(header);
			root.addContent(categories);
			root.addContent(beers);
			d.addContent(root);
		}
		catch(Exception e) { e.printStackTrace(); }
		
		return d;
	}
	
	private static void addXMLContent(Element elem, int xmlchildindex, String str)
	{
		if(!str.equals("") && !str.equals(STANDARDCHILDVALUES[xmlchildindex]))
			elem.addContent(new Element(XMLCHILDNAMES[xmlchildindex]).setText(str));
	}
	
	
	
	
	public static Pub readStevanFile() throws FileNotFoundException
	{
		Pub pub = new Pub();
		FileReader reader = new FileReader("data.txt");
		Scanner in = new Scanner(reader);
		
		BeerCategory currentCategory = null;
		int i = 0;
		while(in.hasNextLine())
		{
			String line = in.nextLine();
			if(!line.equals("") && !line.startsWith("##") && !line.equals("}") && !line.equals("{-") && !line.equals("-}"))
			{
				if(line.endsWith(" {"))
				{
					currentCategory = new BeerCategory(line.substring(0, line.indexOf(" {")), i);
					i++;
				}
				else
				{
					int stock = -1;
					
					String searchstr = "# ";
					if(line.startsWith(searchstr))
					{
						stock = 0;
						line = line.substring(searchstr.length());
					}
					
					BeerStock beerstock = new BeerStock(parseStevanLine(line), currentCategory, stock, stock);
					pub.add(beerstock);
				}
			}
		}
		
		in.close();
		return pub;
	}
	
	
	private static Beer parseStevanLine(String line)
	{
		line = line.replaceAll("\t", "");
		String[] data = line.split(";");
		
		for(int i = 0; i < data.length; i++)
			if(data[i].charAt(0) == ' ')
				data[i] = data[i].substring(1, data[i].length());

		
		data[3] = removePostfix(data[3], "%");
		data[4] = removePostfix(data[4], " ml");
		
		
		double buyprice = (-1.0);
		int sellprice;
		
		if(data[5].indexOf("{-") != -1)
		{
			sellprice = Integer.parseInt(data[5].substring(0, data[5].indexOf(" kr")));
			
			data[5] = data[5].substring(data[5].indexOf("# "));
			data[5] = data[5].replaceAll("# ", "");
			data[5] = removePostfix(data[5], " kr -}");
			
			try{ buyprice = Double.parseDouble(data[5]); }
			catch(Exception e) { e.printStackTrace(); }
		}
		else
			sellprice = Integer.parseInt(removePostfix(data[5], " kr"));
		
		return new Beer(data[0], data[1], data[2], Double.parseDouble(data[3]), 
						Integer.parseInt(data[4]), -1, buyprice, sellprice);
	}
	
	private static String removePostfix(String input, String searchTerm)
	{
		int pos = input.indexOf(searchTerm);
		if(pos != -1)
			input = input.substring(0, pos);
		return input;
	}
}
