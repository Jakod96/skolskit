/*
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
*/

import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;



public class Main
{
	private static final String DATAFILE = "data.xml";
	
	public static void main(String[] args)
	{
		Pub pub = null;
		try
		{
//			pub = PubIO.readStevanFile();
			pub = PubIO.readXMLFile(new File(DATAFILE));
			pub.sort();
/*			Document d0 = PubIO.createXMLFile(pub);
			Document d1 = PubIO.createXMLFile(PubIO.readXMLFile(new File("data.xml")));
			
			
			FileWriter fw = new FileWriter("data.xml");
			
			XMLOutputter b = new XMLOutputter();
			b.setFormat(Format.getPrettyFormat());
			b.output(d1, fw);
			fw.close();
*/		}
		catch(FileNotFoundException e)
		{
			JOptionPane.showMessageDialog(null, 
				"Could not open " + DATAFILE + ".", "Can't find file!", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, 
					"Error when initializing program", "Error!", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
		
		
		JFrame frame = new GUI(pub);
		frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		frame.setTitle("Pubtools 2.0");
		frame.setVisible(true);
	}
}