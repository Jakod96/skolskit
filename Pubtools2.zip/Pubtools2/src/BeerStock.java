
public class BeerStock implements Cloneable, Comparable<BeerStock>
{
	// Den här klassen ska innehålla en ölsort, hur många vi har inne samt ölens kategori
	public BeerStock(Beer b, BeerCategory c)
	{
		category    = c;
		beer        = b;
		stockbefore = 0;
		stockafter  = 0;
		tofridge    = 0;
		fromfridge  = 0;
	}
	
	public BeerStock(Beer b, BeerCategory c, int sb, int sa)
	{
		category    = c;
		beer        = b;
		stockbefore = sb;
		stockafter  = sa;
		tofridge    = 0;
		fromfridge  = 0;
	}
	
	public BeerCategory getCategory()		{ return category; }
	public Beer getBeer()					{ return beer; }
	public int getStockBefore()				{ return stockbefore; }
	public int getStockAfter()				{ return stockafter; }
	public int getToFridge()				{ return tofridge; }
	public int getFromFridge()				{ return fromfridge; }
	public int getMinAmount()				{ return minamount; }
	public int getWishAmount()				{ return wishamount; }
	
	public void setBeer(Beer b)				{ beer        = b; }
	public void setStockBefore(int s)		{ stockbefore = s; }
	public void setStockAfter(int s)		{ stockafter  = s; }
	public void setToFridge(int s)			{ tofridge    = s; }
	public void setFromFridge(int s)		{ fromfridge  = s; }
	public void setMinAmount(int s)			{ minamount   = s; }
	public void setWishAmount(int s)		{ wishamount  = s; }
	public void setCategory(BeerCategory c)	{ category    = c; }
	
	public int stockDiff()					{ return stockbefore - stockafter; }
	public double moneyMade()
	{
		double bp = beer.getBuyprice();
		// If the buyprice is unknown (-1.0), then assume it is 20% less than the sell price.
		if(bp == -1.0)
			bp = beer.getSellprice() * 0.8;
		return (stockbefore - stockafter) * (beer.getSellprice() - bp);
	}
	public double percentageSold()
	{
		if(stockbefore == 0)
			return -1.0;
		return (double)(stockbefore - stockafter) / stockbefore * 100;
	}
	
	public int compareTo(BeerStock s)
	{
		if(category.compareTo(s.getCategory()) >= 1)
			return 1;
		else if(category.compareTo(s.getCategory()) <= -1)
			return -1;
		
		
		if(beer.getName().compareTo(s.getBeer().getName()) >= 1)
			return 1;
		if(beer.getName().equals(s.getBeer().getName()))
			return 0;
		return -1;
	}
	
	public BeerStock clone()
	{
		try
		{
			BeerStock clone = (BeerStock) super.clone();
			clone.beer = this.beer.clone();
			clone.category = this.category.clone();
			
			return clone;
		}
		catch(CloneNotSupportedException e) { }
		return null;
	}
	
	public boolean equals(Object o)
	{
		if(o == null || (!(o instanceof BeerStock)))
			return false;
		BeerStock b = (BeerStock)o;
		if((b.stockbefore == this.stockbefore) && (b.stockafter == this.stockafter) && (b.tofridge == this.tofridge) &&
			(b.fromfridge == this.fromfridge) && (b.minamount == this.minamount) && (b.wishamount == this.wishamount) && 
			(b.beer.equals(this.beer)) && (b.category.equals(this.category)))
			return true;
		return false;
	}
	
	public String toString()
	{
		return beer.getName();
	}
	
	private int stockbefore;
	private int stockafter;
	private int tofridge;
	private int fromfridge;
	private int minamount;
	private int wishamount;
	private Beer beer;
	private BeerCategory category;
}