
public class Store
{
	private String adr;
	private String nick;
	private int amount;
	
	public Store(String adr, String nick, int amount)
	{
		this.adr    = adr;
		this.nick   = nick;
		this.amount = amount;
	}
	
	public String getAdress()		{ return adr; }
	public String getNick()			{ return nick; }
	public int getAmount()			{ return amount; }
	
	public Store clone()
	{
		try {
			return (Store)super.clone();
		}
		catch(CloneNotSupportedException e) { }
		return null;
	}
	
	public String toString()
	{
		return adr;
	}
}
