import java.util.Arrays;


public class Beer implements Cloneable
{
	public Beer(String n, String t, String c, double a, int v, int i, double b, int s)
	{
		name      = n;
		type      = t;
		country   = c;
		abv       = a;
		volume    = v;
		id        = i;
		buyprice  = b;
		sellprice = s;
		stores    = null;
	}
	
	public String getName()				{ return name; }
	public String getType()				{ return type; }
	public String getCountry()			{ return country; }
	public double getAbv()				{ return abv; }
	public int getVolume()				{ return volume; }
	public int getId()					{ return id; }
	public double getBuyprice()			{ return buyprice; }
	public int getSellprice()			{ return sellprice; }
	public double getApk()				{ return abv * volume / (100 * sellprice); }
	public Store[] getStores()			{ return stores; }
	
	public void setName(String n)		{ name      = n; }
	public void setType(String t)		{ type      = t; }
	public void setCountry(String c)	{ country   = c; }
	public void setAbv(double a)		{ abv       = a; }
	public void setVolume(int v)		{ volume    = v; }
	public void setId(int i)			{ id        = i; }
	public void setBuyprice(double b)	{ buyprice  = b; }
	public void setSellprice(int s)		{ sellprice = s; }
	public void setStores(Store[] s)	{ stores    = s; }
	
	public String getStoresNick()
	{
		if(stores == null)
			return "";
		
		String output = "";
		for(int i = 0; i < stores.length; i++)
			output += stores[i].getNick() + " ";
		
		return output;
	}
	public String getStoresData()
	{
		if(stores == null)
			return "";
		
		String output = "";
		for(int i = 0; i < stores.length; i++)
			output += stores[i].getAdress() + ": " + stores[i].getAmount() + "\n";
		
		return output;
	}
	
	public Beer clone()
	{
		try{
			Beer clone = (Beer)super.clone();
			if(this.stores != null)
			{
				clone.stores = this.stores.clone();
				for(int i = 0; i < stores.length; i++)
					clone.stores[i] = (Store)this.stores[i].clone();
			}
			
			return clone;
		} catch(CloneNotSupportedException e) { }
		return null;
	}
	
	public boolean equals(Object o)
	{
		if(o == null || (!(o instanceof Beer)))
			return false;
		Beer b = (Beer)o;
		if(b.name.equals(this.name) && b.type.equals(this.type) && b.country.equals(this.country) && 
			(b.abv == this.abv) && (b.volume == this.volume) && (b.id == this.id) && 
			(b.buyprice == this.buyprice) && (b.sellprice == this.sellprice) && Arrays.equals(b.stores, this.stores))
			return true;
		return false;
	}
	
	private String name;
	private String type;
	private String country;
	private double abv;
	private int volume;
	private int id;
	private double buyprice;
	private int sellprice;
	private Store[] stores;
}