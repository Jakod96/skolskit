import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.WindowConstants;

public class ProgressDialog extends JFrame
{
	private static final long serialVersionUID = -2662952815497207921L;
	private JLabel progress  = new JLabel("Progress: ");
	private JButton btn      = new JButton("Abort");
	private JProgressBar bar = new JProgressBar();
	private int max;
	
	public ProgressDialog()
	{
		super("Progress");
		bar.setMinimum(0);
		bar.setValue(0);
		bar.setStringPainted(true);
		
		Container container = new Container();
		container.setLayout(new GridLayout(0, 1));
		container.add(progress);
		container.add(bar);
		container.add(btn);

		this.getContentPane().add(container, BorderLayout.CENTER);
		
		btn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				abort();
			}
		});
		
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				abort();
			}
		});
		pack();
	}
	
	
	private void abort()
	{
//		PubIO.continueDownloading(false);
		dispose();
	}
	
	public void setTasks(int i)
	{
		max = i;
		bar.setMaximum(i);
	}
	
	public void setBar(int i)
	{
		System.out.println(i);
		bar.setValue(i);
		progress.setText("Progress: " + i + " of " + max);
	}
	
	
	public void display()
	{
		setVisible(true);
	}
	
	public void rem()
	{
		setVisible(false);
	}
}