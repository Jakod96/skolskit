
public class BeerCategory implements Cloneable, Comparable<BeerCategory>
{
	// Den här klassen innehåller en String med kategorins namn och en int med dess 
	// numeringstal. Lager har tal 0, Ale har tal 1 etc.
	public BeerCategory(String n, int o)
	{
		name  = n;
		order = o;
	}
	
	public void setName(String n)	{ name = n; }
	public void setOrder(int o)		{ order = o; }
	public String getName()			{ return name; }
	public int getOrder()			{ return order; }
	
	public int compareTo(BeerCategory c)
	{
		if(order < c.getOrder())
			return -1;
		if(order > c.getOrder())
			return 1;
		return 0;
	}
	
	public BeerCategory clone()
	{
		try {
			return (BeerCategory)super.clone();
		}
		catch(CloneNotSupportedException e) { }
		return null;
	}
	
	public boolean equals(Object o)
	{
		if(o == null || (!(o instanceof BeerCategory)))
			return false;
		if(((BeerCategory)o).name.equals(this.name) && ((BeerCategory)o).order == this.order)
			return true;
		return false;
	}
	
	
	private String name;
	private int order;
}
