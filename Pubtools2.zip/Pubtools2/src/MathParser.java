import java.util.StringTokenizer;


// Code comes from http://www.cs.uiowa.edu/~hzhang/c21/project2.html
// It has been trimmed and downsized to only allow expressions containing +,-,* and /
public class MathParser
{
	private double value;
	private boolean valid;
	
	public MathParser(String expr)
	{
		value = -1.0;
		valid = false;
		try
		{
			Evaluator a = new Evaluator(expr);
			value = a.getValue();
			valid = true;
		}
		catch(Exception e)
		{
			valid = false;
			value = -1.0;
		}
		
	}
	
	public boolean isValid()	{ return valid; }
	public double getValue()	{ return value; }
	
	
	
	public class Evaluator
	{
		private double value;
		private EvalTokenizer str;
		
		public Evaluator(String s)
		{
			str = new EvalTokenizer(s);
			value = evaluate();
		}
		
		public double getValue()
		{
			return value;
		}
		private double evaluate()
		{
			return evalExpression(str.getToken());
		}
		
		private double evalExpression(Token firstToken)
		{
			/* <expression> ::= <term> 
							  | <expression> + <term>
							  | <expression> - <term>
			*/
			double x = evalTerm(firstToken);
			while(true)
			{
				String op = str.peekToken().getType();
				if(op.equals("+") || op.equals("-"))
				{
					str.getToken(); // skip "+" or "-"
					double y = evalTerm(str.getToken());
					if(op.equals("+"))
						x += y;
					else
						x -= y;
				}
				else
					return x;
			}
		}
		
		private double evalTerm(Token firstToken)
		{
			/* <term> ::= <factor>
						| <term> * <factor>
						| <term> / <factor>
			*/
			double x = evalFactor(firstToken);
			while(true)
			{
				String op = str.peekToken().getType();
				if(op.equals("*") || op.equals("/"))
				{
					str.getToken(); // skip "*" or "/"
					double y = evalFactor(str.getToken());
					if(op.equals("*"))
						x = x*y;
					else
						x = x/y;
				}
				else
					return x;
			}
		}
		
		private double evalFactor(Token firstToken) throws ArithmeticException
		{
			/* <factor> ::= ( <expression> )
						| + <factor>
						| - <factor>
						| <variable>  
						| ++ <variable>  
						| -- <variable>
						| <number> 
			*/
			String t = firstToken.getType();
			
			if(t.equals("("))
			{
				// <factor> ::= ( <expression> )
				double x = evalExpression(str.getToken());
				String nex = str.getToken().getType();
				if(!nex.equals(")"))
					throw new ArithmeticException("bad expression");
				return x;
			}
			
			// <factor> ::= + <factor> | - <factor>
			if(t.equals("+"))
				return evalFactor(str.getToken());
			if(t.equals("-"))
				return -evalFactor(str.getToken());
			
			// <factor> ::= <number> 
			if(t.equals("_num"))
				return firstToken.getValue(); 

			throw new ArithmeticException("bad expression");
		}
	}
	
	
	
	public class EvalTokenizer
	{
		// Data:
		private StringTokenizer str;
		private Token nextToken = new Token();
		
		public EvalTokenizer(String line)
		{
			str = new StringTokenizer(line, "+*-/()., ", true);
			getToken();
		}
		
		public Token peekToken()
		{
			return nextToken;
		}
		
		/**
		 * A token is either a number literal (integer or double)
		 * getToken finds the next token, skipping blanks, and return it.
		 * For _int or _double token, place the processed value in value.
		 * Throw ArithmeticException if input is unrecognized.
		 */
		public Token getToken() throws ArithmeticException
		{
			Token result = nextToken;
			nextToken = getNextToken();
			String t1 = result.getType();
			String t2 = nextToken.getType();
			if(t2.equals(","))
				t2 = ".";
			
			// handle floating numbers
			if(t1.equals("_num") && t2.equals("."))
			{
				nextToken = getNextToken();
				t2 = nextToken.getType();
				if(!t2.equals("_num"))
					throw new ArithmeticException("number format error");
				
				t2 = nextToken.getName();
				double x = result.getValue() + nextToken.getValue() * Math.pow(10.0, -t2.length());
				nextToken = getNextToken();
				return new Token("_num", "", x);
			}
			
			return result;
		}
		
		private Token getNextToken() throws ArithmeticException
		{
			// Return a default empty token when no more tokens in str.
			if(!str.hasMoreTokens())
				return new Token();

			String s = str.nextToken();
			if(s.equals(" "))
				return getNextToken();

			char c = s.charAt(0);
			if('0' <= c && c <= '9')	// numbers
			{
				long theValue;
				try
				{
					theValue = Long.parseLong(s);
				}
				catch(NumberFormatException e)
				{
					throw new ArithmeticException("number format error");
				}
				return new Token("_num", s, theValue);
			}
			
			return new Token(s, s, 0);
		}
	}
	
	
	
	public class Token
	{
		// Data:
		private String  type = "";
		private String  name = "";
		private double value = 0;
		
		// Constructors:
		public Token()								{ this(""); }
		public Token(String t) 						{ this(t, 0); }
		public Token(String t, double v)			{ this(t, t, v); }
		public Token(String t, String n, double v)
		{
			type = t; name = n; value = v; 
		}
		
		// Methods:
		public String getType()  { return type; }
		public String getName()  { return name; }
		public double getValue() { return value; }
		@Override
		public String toString() { return " type=" + type + " name=" + name + " value=" + value; }
	}
}