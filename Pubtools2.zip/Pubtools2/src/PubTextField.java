// This is a standard TextField that can do 3 things. Feature one is that once the 
// PubTextField gets focus, it will select all text in it, thus allowing the user to 
// quickly overwrite the content with new text.
// Feature two is that the PubTextField can quickly be assigned a new background 
// colour to indicate errors in the content. This is done by calling setError(bool);
// Feature three is that it contains an integer called id that can be used to store
// what id the text field has.


import java.awt.Color;
import java.awt.Font;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;


public class PubTextField extends JTextField implements FocusListener
{
	private static final long serialVersionUID = -3443978728492633412L;
	private int id;
	private boolean error = false;
	
	public PubTextField()					{ super();		init(); }
	public PubTextField(int i)				{ super(i);		init(); }
	public PubTextField(String s)			{ super(s);		init(); }
	public PubTextField(String s, int i)	{ super(s, i);	init(); }
	
	private void init()
	{
		this.setFont(new Font("Verdana", Font.PLAIN, 12));
		addFocusListener(this);
	}
	
	public void focusGained(FocusEvent arg0){ selectAll(); }
	public void focusLost(FocusEvent arg0)  { }
	public void setId(int i)				{ id = i; }
	public int getId()						{ return id; }
	public boolean getError()				{ return error; }
	
	public void setError(boolean err)
	{
		error = err;
		if(err)
			this.setBackground(Color.RED);	// If error is signaled, set to red
		else
			this.setBackground(Color.WHITE);// If no error is signaled, set to default colour
	}
}