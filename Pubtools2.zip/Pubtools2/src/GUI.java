import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.jdom.JDOMException;

public class GUI extends JFrame
{
	private enum MODE { NORMAL, SHOPLIST };
	private static final long serialVersionUID = 6348560702957161266L;
	private final String CLOSE_PASSWORD = "bluto";
	private boolean updated;
	private Pub pub;
	private JCheckBox showSoldOut;
	private JCheckBox showNotSoldOut;
	private PubTextField searchbox;
	private JTable table;
	private Container leftControls;
	private Container area = this.getContentPane();
	private DefaultTableModel tableModel;
	private MODE tableMode;
	
	public GUI(Pub pub)
	{
		tableMode = MODE.NORMAL;
		updated = false;
		this.pub = pub;
		setSize(800, 600);
		this.setExtendedState(this.getExtendedState() | JFrame.MAXIMIZED_BOTH);	// Maximize window
		this.setIconImage(Toolkit.getDefaultToolkit().getImage("delta_logo.png"));
		
		
		initPubtools();
		this.setVisible(true);
		searchbox.requestFocusInWindow();
		
		//TODO:
		// V Fixa så att textfälten markerar all text när man klickar på dom
		// V Skydd mot att exportera øhl för under 20 kr till wikin
		// V Lägg till tratt-skydd så ingen stänger ner programmet utan lösen! 
		// V Presentera relevant info i kolumnerna
		// V About dialog
		// V Implementera pubdatum, namn etc
		// V Hotkeys
		// V Parser för matteuttryck
		// V Maximera vid uppstart
		
		// * Fixa så att statistik-outputten funkar
		// * Fixa progress-dialog till Agentnedladdningen
		// * Se till så att vi inte börjar en ny rubrik precis innan sidan slutar på html-listan
		// * Generera inköpslista
		// * Autosave
		// * Kommentera
		// * Edit categories - still messed up
		// * Bättre sökalgoritm
		// * Städa upp kod
		// * Import saved pub-XML / Stevan file
		// * Undo-system
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				if(updated)
				{
					String ans = (String)JOptionPane.showInputDialog(null,
						"Ändringar i datafilen har gjorts. För att stänga ner programmet " +
						"måste du ange \nlösenord för att bevisa att du är en fin kille " +
						"och inget random-fyllo.",
						"Ange lösenord för att stänga av programmet",
						JOptionPane.PLAIN_MESSAGE);
					if(ans != null && ans.toLowerCase().equals(CLOSE_PASSWORD))
					{
						if(JOptionPane.showConfirmDialog(null,
							"Changes have been made to the data file. Do you want to save?",
							"Do you want to save?", JOptionPane.YES_NO_OPTION) == 0) // yes
						{
							saveXML();
						}
						System.exit(0);
					}
				}
				else
					System.exit(0);
			}
		});
	}
	
	
	private void initPubtools()
	{
		leftControls = new Container();
		leftControls.setLayout(new GridLayout(0, 1));
		
		createControls();
		JButton[] btn = createButtons();
		
		
		for(int i = 0; i < btn.length; i++)
			leftControls.add(btn[i]);
		leftControls.add(searchbox);
		leftControls.add(showSoldOut);
		leftControls.add(showNotSoldOut);
		
		JScrollPane jsc = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		
		
		area.setLayout(new BorderLayout());
		area.add(leftControls, BorderLayout.WEST);
		area.add(jsc, BorderLayout.CENTER);
		
		area.setVisible(true);
		
		updateTableData();
	}
	
	
	private void createControls()
	{
		tableModel = new DefaultTableModel();
		table = new JTable(tableModel);
		table.setAutoCreateRowSorter(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setRowSelectionAllowed(true);
		
		String[] rownames = { "Name", "Category", "Type", "ABV", "Stock before", "To fridge", "From fridge", 
							  "Stock after", "Buy price", "Sell price", "APK" };
		for(int i = 0; i < rownames.length; i++)
			tableModel.addColumn(rownames[i]);
		table.getColumnModel().getColumn(0).setPreferredWidth(175);
		table.getColumnModel().getColumn(1).setPreferredWidth(5);
		table.getColumnModel().getColumn(2).setPreferredWidth(130);
		table.getColumnModel().getColumn(3).setPreferredWidth(15);
		
		
		showSoldOut      = new JCheckBox("Show Sold Out");
		showNotSoldOut   = new JCheckBox("Show Not Sold Out", true);
		ItemListener chb = new ItemListener() { public void itemStateChanged(ItemEvent e) {
			updateTableData(); } };
		
		showSoldOut.addItemListener(chb);
		showNotSoldOut.addItemListener(chb);
		
		
		searchbox = new PubTextField("", 10);
		searchbox.addKeyListener(new KeyListener() { 
			public  void keyPressed (KeyEvent keyEvent) { keyAction(keyEvent, 0); }
			public  void keyTyped   (KeyEvent keyEvent) { }
			public  void keyReleased(KeyEvent keyEvent) { keyAction(keyEvent, 1); }
			private void keyAction  (KeyEvent keyEvent, int type)
			{
				// The input parameter "type" is used to determine if the event is from keyPressed or keyReleased.
				// When we change the selected row in the table, we only want to change on keyPressed, otherwise
				// we would change the selection up / down 2 rows for one button press (eg. move down once for 
				// keyPressed and then move down again for keyReleased).
				int keycode = keyEvent.getKeyCode();
				if(keycode == KeyEvent.VK_DOWN)
				{
					if(type == 0)
						changeSel(table.getSelectedRow() + 1);
				}
				else if(keycode == KeyEvent.VK_UP)
				{
					if(type == 0)
						changeSel(table.getSelectedRow() - 1);
				}
				else if(keycode == KeyEvent.VK_PAGE_UP)
				{
					if(type == 0)
						changeSel(table.getSelectedRow() - 30);
				}
				else if(keycode == KeyEvent.VK_PAGE_DOWN)
				{
					if(type == 0)
						changeSel(table.getSelectedRow() + 30);
				}
				// Do nothing if the user pressed ENTER. Let the code for that keybinding take care of that.
				else if(keycode != KeyEvent.VK_ENTER   && keycode != KeyEvent.VK_ALT   && 
						keycode != KeyEvent.VK_CONTROL && keycode != KeyEvent.VK_SHIFT &&
						keycode != KeyEvent.VK_ESCAPE)
					updateTableData();
			}
			
			private void changeSel(int newrow)
			{
				if(newrow < 0)
					newrow = 0;
				if(newrow >= table.getRowCount())
					newrow = table.getRowCount() - 1;
				table.changeSelection(newrow, 0, false, false);
			}
		});
	}
	
	private JButton[] createButtons()
	{
		String[] btnnames = { "About...", "New Pub / Edit Header...", "Export XML", "Export Beer List",
							  "Export Wiki Table", "Export Statistics", "Export Inventory", "Check Inventory", 
							  "Create Shopping List", "Edit...", "<html><u>A</u>dd new Beer...</html>" };
							  // The hotkey for Add new Beer is Alt+A, so make the 'A' underlined
		JButton[] btn = new JButton[btnnames.length];
		for(int i = 0; i < btn.length; i++)
			btn[i] = new JButton(btnnames[i]);
		
		
		Action editAction = new AbstractAction()
		{
			private static final long serialVersionUID = -528107396566793724L;
			public void actionPerformed(ActionEvent ae)
			{
				int row = table.getSelectedRow();
				if(row != -1)
					new EditDialog((BeerStock)table.getValueAt(row, 0));
			}
		};
		Action addAction = new AbstractAction()
		{
			private static final long serialVersionUID = -3381019543157339629L;
			public void actionPerformed(ActionEvent ae)
			{
				new EditDialog(null);
			}
		};
		Action homeAction = new AbstractAction()
		{
			private static final long serialVersionUID = 1148536792558547221L;
			public void actionPerformed(ActionEvent ae)
			{
				table.changeSelection(0, 0, false, false);
			}
		};
		Action endAction = new AbstractAction()
		{
			private static final long serialVersionUID = -2313325605379621827L;
			public void actionPerformed(ActionEvent ae)
			{
				table.changeSelection(table.getRowCount() - 1, 0, false, false);
			}
		};

		this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke("ENTER"), "edit");
		this.getRootPane().getActionMap().put("edit", editAction);
		this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.ALT_MASK), "add");
		this.getRootPane().getActionMap().put("add", addAction);
		table.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "edit");
		table.getActionMap().put("edit", editAction);
		table.getInputMap().put(KeyStroke.getKeyStroke("HOME"), "home");
		table.getActionMap().put("home", homeAction);
		table.getInputMap().put(KeyStroke.getKeyStroke("END"), "end");
		table.getActionMap().put("end", endAction);

		
		
		btn[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae)
			{
				new AboutDialog();
			}
		});
		btn[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae)
			{
				new HeaderDialog();
			}
		});
		btn[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae)
			{
				saveXML();
			}
		});
		btn[3].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				try{ PubIO.exportPubList(pub, new File("lista.html"));
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn[4].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				try{ PubIO.exportWikiTable(pub, new File("wiki.txt"));
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn[5].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				try
				{
					if(JOptionPane.showConfirmDialog(null,
							"Do you want to download inventory data from Systembevakningsagenten and Systembolaget?\n" +
							"This will probably take quite some time, depending on how fast their web servers are.",
							"Download inventory data from the Agent?", JOptionPane.YES_NO_OPTION) == 0) // yes
					{
						PubIO.exportPubStatistics(pub, new File("statistics.html"), true);
						JOptionPane.showMessageDialog(null, "The statistics file has been generated and saved!");
					}
					else
					{
						PubIO.exportPubStatistics(pub, new File("statistics.html"), false);
					}
				}
				catch(JDOMException e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				} catch(IOException e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn[6].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				try{ PubIO.exportInventory(pub, new File("inventory.html"));
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btn[7].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				if(JOptionPane.showConfirmDialog(null,
						"This action will loop through all beers in the database and \n" +
						"set the Stock After data to 0. This is useful when you check \n" +
						"the inventory. Are you sure you want to set the Stock After \n" +
						"data to 0 for all beers? This cannot be undone.",
						"Really set the Stock After data to 0 for all beers?", JOptionPane.YES_NO_OPTION) == 0) // yes
				{
					for(int i = 0; i < pub.size(); i++)
						pub.getBeerStock(i).setStockAfter(0);
					updateTableData();							// Empty and fill the table with the updated data
				}
			}
		});
		btn[8].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				new ShopList();
			}
		});
		btn[9].addActionListener(editAction);
		btn[10].addActionListener(addAction);
		
		
		return btn;
	}
	
	private void saveXML()
	{
		try{ PubIO.exportPubXML(pub, new File("data.xml"));
		} catch(IOException e) { System.out.println("A failer is you"); }
	}
	
	
	private void updateTableData()
	{
		// Remove the table data
		while(tableModel.getRowCount() > 0)
			tableModel.removeRow(0);
		
		
		for(int i = 0; i < pub.size(); i++)
		{
			if(checkIfWeShouldAdd(pub.getBeerStock(i)))
			{
				Beer beer = pub.getBeer(i);
				String[] strings = { beer.getName(), beer.getType(), beer.getCountry() };
				for(int j = 0; j < strings.length; j++)
					strings[j] = normalizeText(strings[j]); 
				
				
				String searchstr = normalizeText(searchbox.getText());
				for(int j = 0; j < strings.length; j++)
				{
					if(strings[j].contains(searchstr))
					{
						addTableRow(pub.getBeerStock(i));	// The beerstock of the current beer
						break;
					}
				}
			}
		}
		table.changeSelection(0, 0, false, false);		// Always select first item when we search
	}
	
	
	private String normalizeText(String str)
	{
		str = str.toLowerCase();
		str = str.replaceAll("ü", "u");
		str = str.replaceAll("y", "u");		// <-- This means that you will get results containing 'u' but no 'y's. 
		str = str.replaceAll("ø", "ö");		// We consider this an acceptable side effect. The reason for this
		str = str.replaceAll("æ", "ä");		// rule is to be able so search for "Früli", both by writing "Fruli"
		str = str.replaceAll("é", "e");		// and "Fryli"
		str = str.replaceAll("è", "e");
		str = str.replaceAll("ë", "e");
		str = str.replaceAll("ó", "o");
		str = str.replaceAll("ò", "o");
		str = str.replaceAll("ß", "ss");
		str = str.replaceAll("'", "");
		str = str.replaceAll("-", "");
		return str;
	}
	
	
	
	private boolean checkIfWeShouldAdd(BeerStock bs)
	{
		return (showNotSoldOut.isSelected() && bs.getStockBefore() != 0) || 
				  (showSoldOut.isSelected() && bs.getStockBefore() == 0);
		
	}
	
	private void addTableRow(BeerStock bs)
	{
		Beer beer = bs.getBeer();
		if(tableMode == MODE.NORMAL)
			tableModel.addRow(new Object[]{ bs,                 bs.getCategory().getOrder(), 
											beer.getType(),     beer.getAbv(),       bs.getStockBefore(),
											bs.getToFridge(),   bs.getFromFridge(),  bs.getStockAfter(), 
											beer.getBuyprice(), beer.getSellprice(), beer.getApk() });
		else
		{
			double price  = beer.getBuyprice();
			tableModel.addRow(new Object[]{ bs,      bs.getStockAfter(),             bs.stockDiff(),
											price,   new Integer(bs.getMinAmount()), new Integer(bs.getWishAmount()), 
											price *  bs.getMinAmount(), price * bs.getWishAmount(), beer.getStoresNick()
			});
		}
	}
	
	
	private class EditDialog extends PubDialog
	{
		private static final long serialVersionUID = -2672370967410730254L;
		private boolean edit = true;
		private Beer beer;
		private BeerStock beerstock;
		private ArrayList<BeerCategory> beercat;
		
		
		private String[] values = { "", "", "", "-1.0", "-1", "-1", "-1.0", "-1", "-1", "-1", "-1", "-1" };
		private int tofridge;
		private int catOrder;
		
		private JComboBox dropdown;
		private PubTextField[] tfs;
		private PubTextField[] exprs;
		
		public EditDialog(BeerStock bs)
		{
			beerstock = bs;
			
			if(beerstock == null)
				edit = false;
			init();
			
			
			
			beercat = pub.getBeerCategory();
			String[] catnames = new String[beercat.size()];
			int selection = 0;
			for(int j = 0; j < beercat.size(); j++)
			{
				catnames[j]  = beercat.get(j).getName();
				if(catOrder == beercat.get(j).getOrder())
					selection = j;
			}
			
			dropdown = new JComboBox(catnames);
			dropdown.setSelectedIndex(selection);
			
			JButton btnr = new JButton("Remove Beer");
			btnr.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					if(edit)
					{
						if(JOptionPane.showConfirmDialog(null,
								"This will permanently remove the current beer from the database. \n" +
								"There is no problem in keeping sold out beers in the database, so \n" +
								"you do not need to remove beers. Are you sure you still want to remove it?",
								"Really remove beer?", JOptionPane.YES_NO_OPTION) == 0) // yes
						{
							pub.remove(pub.getIndex(beer.getName()));
							updateTableData();				// Update the table (ie remove it visually)
							close();
						}
					}
					else
						JOptionPane.showMessageDialog(null, "You can't remove a beer not yet created.", 
								"Error", JOptionPane.ERROR_MESSAGE);
				}
			});
			JButton btn0 = new JButton("Edit Categories");
			btn0.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					// By clicking this button, we bring up the Edit Categories dialog. In it, the
					// user has the ability to make changes that affect the beer that is currently
					// being edited (for example, the user can remove all beers that exist in the 
					// current beer's category, thus also removing the current beer). To prevent
					// errors and strange behavior, we first check if the user has made any changes
					// to the beer before clicking this button. If changes have been made, the user
					// must first save or discard them before (s)he can bring up the Edit Categories
					// dialog. 
					boolean updateMade = false;
					for(int i = 0; i < tfs.length; i++)
						if(!tfs[i].getText().equals(values[i]))
							updateMade = true;
					
					if(catOrder != dropdown.getSelectedIndex())
						updateMade = true;
					
					if(!updateMade)
					{
						new CatDialog();
						close();
					}
					else
						JOptionPane.showMessageDialog(null, "You have made changes to the beer in this dialog.\n" +
								"To prevent errors, you must first save or discard the changes before you can \n" +
								"open the Edit Categories dialog. In other words, you must either click OK or \n" +
								"Cancel now, before you can open the Edit Categories dialog.", 
								"Please save or discard the changes first", JOptionPane.ERROR_MESSAGE);
				}
			});
			
			
			// The container and the GridBagConstraints are for placing the components in the dialog
			Container container = new Container();
			container.setLayout(new GridBagLayout());
			
			GridBagConstraints c0 = new GridBagConstraints();
			c0.fill = GridBagConstraints.HORIZONTAL;
			c0.weightx = 0.0;
			c0.gridwidth = 1;
			c0.gridy = 0;
			c0.gridx = 0;
			
			GridBagConstraints c1 = (GridBagConstraints)c0.clone();
			c1.gridwidth = 2;
			c1.weightx = 0.5;
			c1.gridx = 1;

			GridBagConstraints c2 = (GridBagConstraints)c1.clone();
			c2.gridwidth = 1;
			c2.weightx = 1.0;
			c2.gridx = 1;

			GridBagConstraints c3 = (GridBagConstraints)c2.clone();
			c3.weightx = 0.0;
			c3.gridx = 2;
			
			GridBagConstraints c4 = (GridBagConstraints)c1.clone();
			c4.gridwidth = 3;
			c4.gridx = 0;
			c4.gridy = 1;
			
			container.add(btnr, c0);
			container.add(btn0, c1);
			container.add(dropdown, c4);
			c0.gridy = 2;
			c1.gridy = 2;
			
			final Runnable[] cmds = addLabelsAndTextfields(container, c0, c1, c2, c3);
			
			
			JButton btn1 = new JButton("OK");
			btn1.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					// This action will be executed when the user either clicks the OK button or
					// when the user presses enter. If the latter is the case, the textfields will
					// won't fire their focusLost focus events, which the logic depends on. 
					// Thus, we begin by looping through all the focusLost events of the textfields. 
					for(int i = 0; i < tfs.length; i++)
					{
						FocusListener[] fls = tfs[i].getFocusListeners();
						for(int j = 0; j < fls.length; j++)
							fls[j].focusLost(new FocusEvent(tfs[i], FocusEvent.FOCUS_LOST));
					}
					
					// First, check if any text field contains errors. If they do, don't let
					// the user save without correcting the errors. Also, check if there are 
					// any updates to the data. If the user has changed any of the data, then
					// set the updateMade flag. If the user clicked OK without doing any changes
					// then just hide the Edit dialog.
					boolean updateMade = false;
					for(int i = 0; i < tfs.length; i++)
					{
						if(tfs[i].getError())
						{
							JOptionPane.showMessageDialog(null, "Errors exist in the provided data. Correct the " +
									"errors before saving!", "Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						if(!tfs[i].getText().equals(values[i]))
							updateMade = true;
					}
					int i = dropdown.getSelectedIndex();
					if(catOrder != i)
					{
						updateMade = true;
						beerstock.setCategory(beercat.get(i));
					}
					
					
					if(!updateMade)			// No updates made, just close the dialog 
						close();
					updated = updateMade;
					
					
					// We now know that the user has updated the data. The FocusListeners are
					// responsible for making sure that the data is correct, and without errors, 
					// and since we have checked for errors already, we know that the data 
					// should be good. Let the array of cmds take care of saving the data. 
					for(i = 0; i < cmds.length; i++)
						cmds[i].run();
					
					
					if(!edit)
					{
						pub.add(beerstock);
						pub.sort();
						updateTableData();
					}
					else if(updateMade)
					{
						// Changes may have been made that should be reflected in the table. 
						// Call the search() function to update the table. search() selects 
						// the first row, which we don't want. Re-select the currently selected 
						// row after search() has been called. 
						int row = table.getSelectedRow();
						updateTableData();
						table.changeSelection(row, 0, false, false);
					}
					close();
				}
			});
			
			
			JButton btn2 = new JButton("Cancel");
			btn2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0) { close(); }});
			
			container.add(btn1, c0);
			container.add(btn2, c1);
			
			
			setTitle("Add / Edit Beer");
			getContentPane().add(container, BorderLayout.CENTER);
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.getRootPane().setDefaultButton(btn1);
			this.pack();
			this.setVisible(true);
			
			
			// Close the dialog if the user presses the escape key. This is done automatically in the 
			// PubDialog class, but that class calls dispose(), while we want to call close()
			// when this dialog is closed. Thus we have to "remap" the escape key. 
			Action escAction = new AbstractAction()
			{
				private static final long serialVersionUID = -3947392756582202933L;
				public void actionPerformed(ActionEvent ae) { close(); }
			};
			this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
					.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "esc");
			this.getRootPane().getActionMap().put("esc", escAction);
			
			
			// Select the To Fridge text box, if we are editing a beer. 
			// If we're adding a beer, then the default selection is fine so don't do nothing.
			if(edit)
				tfs[9].requestFocusInWindow();
		}
		
		private void init()
		{
			if(!edit)
			{
				catOrder = 0;
				beer = new Beer(values[0], values[1], values[2], Double.parseDouble(values[3]), 
								Integer.parseInt(values[4]), Integer.parseInt(values[5]), 
								Double.parseDouble(values[6]), Integer.parseInt(values[7]));
				beerstock = new BeerStock(beer, pub.getBeerCategory().get(0), 
								Integer.parseInt(values[8]), Integer.parseInt(values[11]));
			}
			else
			{
				beer = beerstock.getBeer();
				
				values[0]  = beer.getName();
				values[1]  = beer.getType();
				values[2]  = beer.getCountry();
				values[3]  = beer.getAbv() + "";
				values[4]  = beer.getVolume() + "";
				values[5]  = beer.getId() + "";
				values[6]  = beer.getBuyprice() + "";
				values[7]  = beer.getSellprice() + "";
				values[8]  = beerstock.getStockBefore() + "";
				values[9]  = beerstock.getToFridge() + "";
				values[10] = beerstock.getFromFridge() + "";
				values[11] = beerstock.getStockAfter() + "";
				catOrder   = beerstock.getCategory().getOrder();
			}
		}
		
		private void set125percent(double d)
		{
			exprs[0].setText("" + (d * 1.25));
		}
		
		
		private Runnable[] addLabelsAndTextfields(Container container, GridBagConstraints c0, 
				GridBagConstraints c1, GridBagConstraints c2, GridBagConstraints c3)
		{
			// Some of the text fields should do stuff once they lose focus.
			// The following things should happen:
			// 1. A field that expects an int should check that an int has been 
			//    provided by the user once the field loses focus. If it isn't an 
			//    int, then the field should indicate this.
			// 2. The same thing goes for doubles, if an incorrect double has been
			//    provided, then indicate this
			// 3. For fields that allow mathematical expressions, we need to calculate
			//    its value and make sure there are no errors. Give the computed 
			//    value of the expression in the "answer field" to the right. 
			// 4. When the user enters a new "buy price", we should multiply that
			//    value with 125% and give that product in the "answer field" to 
			//    the right of the sell sum, in order to give a guiding number of 
			//    how large the sell sum should be.
			//
			// We make the text fields react this way by making FocusListeners 
			// that we associate with each text field.
			FocusListener defFL = new FocusListener()			// Default focus listener - does nothing
			{
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)   { }
			};
			FocusListener nameFL = new FocusListener()			// Name focus listener - makes sure the name doesn't 
			{													// appear in the pub database twice
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)
				{
					PubTextField tfld = (PubTextField)arg0.getComponent();
					tfld.setError(false);
					String name = tfld.getText();
					
					for(int i = 0; i < pub.size(); i++)
						if((!pub.getBeer(i).equals(beer)) && 
								normalizeText(pub.getBeer(i).getName()).equals(normalizeText(name)))
							tfld.setError(true);
				}
			};
			FocusListener intFL = new FocusListener()			// Int focus listener - alarm if value isn't an int
			{
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)
				{
					PubTextField tfld = (PubTextField)arg0.getComponent();
					try
					{
						Integer.parseInt(tfld.getText());
						tfld.setError(false);
					}
					catch(Exception e){
						tfld.setError(true);		// Got exception when converting to int. Indicate this!
			}}};
			FocusListener doubleFL = new FocusListener()		// Double focus listener - alarm if value isn't a double
			{
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)
				{
					PubTextField tfld = ((PubTextField)arg0.getComponent());
					try
					{
						// Replace the ',' with '.' so we can denote decimals the standard Swedish way.
						String repstr = tfld.getText().replace(',', '.');
						Double.parseDouble(repstr);
						tfld.setText(repstr);
						tfld.setError(false);
					}
					catch(Exception e){
						tfld.setError(true);		// Got exception when converting to double. Indicate this!
			}}};
			FocusListener bpFL = new FocusListener()			// Buy price focus listener - set exprs[0] to be 125% 
			{													// of the buy price
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)
				{
					PubTextField tfld = ((PubTextField)arg0.getComponent());
					try
					{
						// Replace the ',' with '.' so we can denote decimals the standard Swedish way.
						String repstr = tfld.getText().replace(',', '.');
						set125percent(Double.parseDouble(repstr));
						tfld.setText(repstr);
						tfld.setError(false);
					}
					catch(Exception e){
						tfld.setError(true);		// Got exception when converting to double. Indicate this!
			}}};
			FocusListener calcFL = new FocusListener()			//Calculation focus listener - Calculates the value of 
			{													//the textfield & alarms if it isnt a correct expression
				public void focusGained(FocusEvent arg0) { }
				public void focusLost(FocusEvent arg0)
				{
					PubTextField tfld = ((PubTextField)arg0.getComponent());
					try
					{
						// Replace the ',' with '.' so we can denote decimals the standard Swedish way.
						tfld.setText(tfld.getText().replace(',', '.'));
						MathParser expr = new MathParser(tfld.getText());
						if(!expr.isValid())
							throw new Exception("Invalid expression");
						
						
						int tfldid = tfld.getId();
						if(tfldid > 0)
							exprs[tfldid].setText("" + (int)expr.getValue());
						
						calculateFridgeSum();
						if(exprs[2].getText().equals("0"))
							enableStockAfter(true);
						else
							enableStockAfter(false);
						
						tfld.setError(false);
					}
					catch(Exception e){
						tfld.setError(true);		// Got exception when parsing expression. Indicate this!
			}}};
			
			
			
			
			
			Runnable cmdName = new Runnable(){ public void run() {
				beer.setName(tfs[0].getText());
			}};
			Runnable cmdType = new Runnable(){ public void run() {
				beer.setType(tfs[1].getText());
			}};
			Runnable cmdCountry = new Runnable(){ public void run() {
				beer.setCountry(tfs[2].getText());
			}};
			Runnable cmdAbv = new Runnable(){ public void run() {
				beer.setAbv(Double.parseDouble(tfs[3].getText()));
			}};
			Runnable cmdVolume = new Runnable(){ public void run() {
				beer.setVolume(Integer.parseInt(tfs[4].getText()));
			}};
			Runnable cmdId = new Runnable(){ public void run() {
				beer.setId(Integer.parseInt(tfs[5].getText()));
			}};
			Runnable cmdBP = new Runnable(){ public void run() {
				beer.setBuyprice(Double.parseDouble(tfs[6].getText()));
			}};
			Runnable cmdSP = new Runnable(){ public void run() {
				beer.setSellprice(Integer.parseInt(tfs[7].getText()));
			}};
			Runnable cmdSB = new Runnable(){ public void run() {
				beerstock.setStockBefore(Integer.parseInt(exprs[1].getText()));
			}};
			Runnable cmdTF = new Runnable(){ public void run() {
				int newTF = Integer.parseInt(exprs[2].getText());
				beerstock.setToFridge(newTF);
				tofridge = newTF;
			}};
			Runnable cmdFF = new Runnable(){ public void run() {
				int newFF = Integer.parseInt(exprs[3].getText());
				beerstock.setFromFridge(newFF);
				if(tofridge != 0)
					beerstock.setStockAfter(beerstock.getStockBefore() - tofridge + newFF);
			}};
			Runnable cmdSA = new Runnable(){ public void run() {
				if(tofridge == 0)
					beerstock.setStockAfter(Integer.parseInt(tfs[11].getText()));
			}};
			
			
			
			String[] labels    = { "Name:", "Type:", "Country:", "ABV:", "Volume:", "ID:", "Buy price:", 
								   "Sell price:", "Stock before:", "To fridge:", "From fridge:", "Stock after:" };
			FocusListener[] fl = { nameFL, defFL, defFL, doubleFL, intFL, intFL, bpFL, 
								   intFL, calcFL, calcFL, calcFL, intFL };
			Runnable[] cmds    = { cmdName, cmdType, cmdCountry, cmdAbv, cmdVolume, cmdId, cmdBP,
								   cmdSP, cmdSB, cmdTF, cmdFF, cmdSA };
			String[] tooltips  = { "25% more than the buy price", "<html>The value of the mathematical expression in " +
					"the field to the left. <br />A valid expression is either +, -, *. / or parenthesis. Example: " +
					"7+(3*24)</html>", "This value is <stock before> - <to fridge> + <from fridge>" };
			
			
			int j;
			exprs = new PubTextField[5];
			tfs   = new PubTextField[values.length];
			
			for(j = 0; j < exprs.length; j++)
			{
				exprs[j] = new PubTextField(5);
				exprs[j].setFocusable(false);
				exprs[j].setToolTipText(tooltips[1]);	// Set all tooltips to tooltip # 1
			}
			exprs[0].setToolTipText(tooltips[0]);		// Set the tooltip for expressionbox 0 and 4
			exprs[4].setToolTipText(tooltips[2]);
			
			
			
			for(j = 0; j < tfs.length - exprs.length; j++)
			{
				c0.gridy++;
				c1.gridy++;
				tfs[j] = new PubTextField(values[j], 20);
				container.add(new JLabel(labels[j]), c0);
				container.add(tfs[j], c1);
				tfs[j].addFocusListener(fl[j]);
			}
			for(int k = 0; j < values.length; j++, k++)
			{
				c2.gridy = ++c0.gridy;
				c3.gridy = ++c1.gridy;
				
				tfs[j] = new PubTextField(values[j]);
				container.add(new JLabel(labels[j]), c0);
				container.add(tfs[j], c2);
				tfs[j].addFocusListener(fl[j]);
				tfs[j].setId(k);
				
				exprs[k].setText(values[j]);
				container.add(exprs[k], c3);
			}
			c0.gridy++;
			c1.gridy++;
			
			
			set125percent(Double.parseDouble(tfs[6].getText()));	// Set the text of the sell price suggestion field
			calculateFridgeSum();									// Set the text of the Stock After Sum 
			if(tfs[9].getText().equals("0"))
				enableStockAfter(true);
			else
				enableStockAfter(false);
			
			tfs[11].setToolTipText("<html>When you save, this value will be the value to the right, <br />" +
					"if the From Fridge value is non-zero. <br />" +
					"You can only enter a number here manually if the From Fridge value is 0.");
			tfs[5].setToolTipText("The Systembolaget internal ID of the beer.");
			
			
			return cmds;
		}
		
		private void enableStockAfter(boolean stock)
		{
			tfs[tfs.length - 1].setEnabled(stock);
			exprs[exprs.length - 1].setEnabled(!stock);
		}
		
		private void calculateFridgeSum()
		{
			exprs[exprs.length - 1].setText("" + (Integer.parseInt(exprs[1].getText()) - 
					  Integer.parseInt(exprs[2].getText()) + 
					  Integer.parseInt(exprs[3].getText())));
		}
		
		
		
		
		private class CatDialog extends PubDialog
		{
			private static final long serialVersionUID = 7470864212842890653L;
			private int selectedindex = 0;
			private JList list = new JList();
			private Pub pubcopy = pub.clone();
			private ArrayList<BeerCategory> catlist;
			
			public CatDialog()
			{
				catlist = pubcopy.getBeerCategory();
				
				list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				JScrollPane jsp = new JScrollPane(list);
				updateList();
				
				
				JButton btnnew  = new JButton("New");
				JButton btnedit = new JButton("Edit");
				JButton btnrem  = new JButton("Remove");
				JButton btnup   = new JButton("Up");
				JButton btndown = new JButton("Down");
				
				btnnew.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						String ans = (String)JOptionPane.showInputDialog(null,
								"Enter the name of the new beer category:",
								"Enter category name",
								JOptionPane.PLAIN_MESSAGE);
						if(ans == null || ans.equals(""))		// User pressed cancel or entered empty string
							return;
						
						selectedindex = catlist.size();
						catlist.add(new BeerCategory(ans, catlist.size()));
						updateList();
					}
				});
				btnedit.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						int sel = list.getSelectedIndex();
						if(sel < 0 || sel >= catlist.size() - 1)	// Incorrect (no) index selected.
							return;
						
						String ans = (String)JOptionPane.showInputDialog(null,
								"Enter the new name of the beer category:", 
								"Enter category name", JOptionPane.PLAIN_MESSAGE,
								null, null, catlist.get(sel).getName());
						if(ans == null || ans.equals(""))		// User pressed cancel or entered empty string
							return;
						
						selectedindex = sel;
						catlist.get(sel).setName(ans);
						updateList();
					}
				});
				btnrem.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						if(catlist.size() == 1)		// There must always be at least one category. Don't allow
							return;					// the user to remove the last one
						
						int sel = list.getSelectedIndex();
						if(sel < 0)					// No list item selected.
							return;
						
						
						Object[] lst = new Object[catlist.size()];
						lst[0] = "Remove all beers in category";
						
						for(int i = 0, j = 1; j < catlist.size(); i++, j++)
						{
							if(catlist.get(i).getName().equals(catlist.get(sel).getName()))
								i++;
							lst[j] = catlist.get(i).getName();
						}
						
						String ans = (String)JOptionPane.showInputDialog(null,
										"You have chosen to remove a category. You can either chose to \n" +
										"delete all beers in this category from the database, or to move\n" +
										"all the beers to another category.", 
										"Move or remove beers?", JOptionPane.PLAIN_MESSAGE,
										null, lst, lst[0]);
						if(ans == null)			// User pressed cancel
							return;
						
						// ans is a String that contains what the user chose. Find the numeric index of the answer 
/*						int i;
						if(ans.equals(lst[0]))
							i = -1;				// Denote that we want to delete all beers with -1.
						else
							for(i = 0; i < catlist.size(); i++)
								if(ans.equals(catlist.get(i).getName()))
									break;
						// i is now the index that corresponds to the text that was entered (or -1 if we are to remove)
						catlist.remove(sel);
						// Reorder the beers
						for(int j = 0; j < catlist.size() - 1; j++)
							if(catlist.get(j).getOrder() != catlist.get(j + 1).getOrder() - 1)
								catlist.get(j + 1).setOrder(catlist.get(j).getOrder() + 1);
						
						
						
						// Go through the whole pub database. Swap all categories with the right indexes.
						for(int j = 0; j < pubcopy.size(); j++)
						{
							if(pubcopy.getCategory(j).getOrder() == sel)// A beer with the selected index
							{
								if(i == -1)								// User wants to remove the beers from the DB
								{
									pubcopy.remove(j);
									j--;								// Decrement - otherwise we'd skip one beer.
								}
								else									// User wants to move beers to another category
									pubcopy.getBeerStock(j).setCategory(catlist.get(i));
							}
							System.out.println(pubcopy.getBeer(j).getName() + " " + 
									pubcopy.getBeerStock(j).getCategory().getName() + " " +
									pubcopy.getBeerStock(j).getCategory().getOrder());
						}
*/						
						
						// ans is a String that contains what the user chose. Find the numeric index of the answer 
						if(ans.equals(lst[0]))
							catlist.set(sel, null);			// Denote that we want to delete all beers
						else
							for(int i = 0; i < catlist.size(); i++)
								if(ans.equals(catlist.get(i).getName()))
								{
									catlist.set(sel, catlist.get(i));
									break;
								}
						
						
						for(int k = 0, dec = 0; k < catlist.size(); k++)
						{
							if(k == sel)		// This is the item we want to remove. Skip it, but denote that
								dec = 1;		// we are to adjust all orders after it, by setting dec to 1.
							else
								catlist.get(k).setOrder(catlist.get(k).getOrder() - dec);
						}
						
						for(int k = 0; k < pubcopy.size(); k++)
						{
							int order = pubcopy.getBeerStock(k).getCategory().getOrder();
							if(catlist.get(order) == null)
							{
								pubcopy.remove(k);		// Remove the beer
								k--;					// Decrement, otherwise the loop skips one beer. 
							}
							else
								pubcopy.getBeerStock(k).setCategory(catlist.get(order));
						}
						catlist.remove(sel);
						
						selectedindex = 0;
						updateList();
					}
				});
				btnup.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						int sel = list.getSelectedIndex();
						if(sel <= 0)			// If the first item is selected, then we can't move it up
							return;				// If no item is selected (-1), then quit
						
						swapList(sel, sel - 1);
						
						selectedindex = sel - 1;
						updateList();
					}
				});
				btndown.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						int sel = list.getSelectedIndex();
						if(sel < 0 || sel == catlist.size() -  1)// If the last item is selected, then we can't move it
							return;								// down. If no item is selected (-1), then quit
						
						swapList(sel, sel + 1);
						
						selectedindex = sel + 1;
						updateList();
					}
				});
				
				
				
				JButton btnok = new JButton("OK");
				btnok.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent ae)
					{
						if(!pubcopy.equals(pub))
						{
							updated = true;
							pubcopy.sort();
							pubcopy.sortCategories();
							pub = pubcopy;
							updateTableData();			// Update the table visually
						}
						dispose();
					}
				});
				JButton btncancel = new JButton("Cancel");
				btncancel.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent arg0) { dispose(); }});
				
				
				
				Container container = new Container();
				container.setLayout(new GridLayout(0, 1));
				container.add(btnnew);
				container.add(btnedit);
				container.add(btnrem);
				container.add(btnup);
				container.add(btndown);
				
				Container okcancel = new Container();
				okcancel.setLayout(new FlowLayout());
				okcancel.add(btnok);
				okcancel.add(btncancel);
				
				
				getContentPane().add(jsp,       BorderLayout.CENTER);
				getContentPane().add(container, BorderLayout.LINE_END);
				getContentPane().add(okcancel,  BorderLayout.PAGE_END);
				setTitle("Edit beer categories");
				this.setSize(400, 300);
				this.setVisible(true);
			}
			
			
			private void swapList(int i, int j)
			{
for(int k = 0; k < catlist.size(); k++)
	System.out.println(k + ". " + catlist.get(k).getName() + " " + catlist.get(k).getOrder());
System.out.println(" ");
				// Swap the category list.
				BeerCategory temp = catlist.get(i);
				int ii = catlist.get(i).getOrder();
				int jj = catlist.get(j).getOrder();
				catlist.set(i, catlist.get(j));
				catlist.get(i).setOrder(ii);
				catlist.set(j, temp);
				catlist.get(j).setOrder(jj);
				
for(int k = 0; k < catlist.size(); k++)
	System.out.println(k + ". " + catlist.get(k).getName() + " " + catlist.get(k).getOrder());
System.out.println(" ");
				
				pubcopy.sortCategories();
				
for(int k = 0; k < catlist.size(); k++)
	System.out.println(k + ". " + catlist.get(k).getName() + " " + catlist.get(k).getOrder());
System.out.println(" ");
				
				// Go through the whole pub database. Swap all categories with the right indexes.
				for(int k = 0; k < pubcopy.size(); k++)
//					pubcopy.getBeerStock(k).setCategory(catlist.get(pubcopy.getBeerStock(k).getCategory().getOrder()));
				{
					if (pubcopy.getBeerStock(k).getCategory().getOrder() == j)
						pubcopy.getBeerStock(k).setCategory(catlist.get(i));
					else if(pubcopy.getBeerStock(k).getCategory().getOrder() == i)
						pubcopy.getBeerStock(k).setCategory(catlist.get(j));
				}
				

			}
			
			
			
			private void updateList()
			{
				list.removeAll();
				String[] strs = new String[catlist.size()];
				for(int i = 0; i < catlist.size(); i++)
					strs[i] = catlist.get(i).getName();
				
				list.setListData(strs);
				list.setSelectedIndex(selectedindex);
			}
		}
		
		private void close()
		{
			searchbox.requestFocus();
			dispose();
		}
	}
	
	
	
	
	public class ShopList
	{
		private Pub pubbackup;
		private JTextArea storeTextArea = new JTextArea("");
		private JProgressBar progressbar = new JProgressBar();
		private JLabel sumlabel = new JLabel("Jenna");
		private double minsum = 0.0;
		private double wishsum = 0.0;
//		private JTable shoplisttable;
		
		public ShopList()
		{
			tableMode = MODE.SHOPLIST;
			pubbackup = pub.clone();
			area.removeAll();
			initShopList();
			
			// Calculate how many bottles we should buy.
			for(int i = 0; i < pub.size(); i++)
			{
				BeerStock bs = pub.getBeerStock(i);
				int j = (bs.stockDiff() - bs.getStockAfter() + 3);
				bs.setMinAmount(j);
				bs.setWishAmount(j);
				double k = j * bs.getBeer().getBuyprice();
				minsum  += k;
				wishsum += k;
			}
			
			updateTableData();
			updateSumLabel();
		}
		
		private void initShopList()
		{
			area.setVisible(false);							// Hide everything in order to force a redrawing later
			leftControls = new Container();
			leftControls.setLayout(new GridLayout(0, 1));
			
			JButton[] btn = createButtons();
			
			
			for(int i = 0; i < btn.length; i++)
				leftControls.add(btn[i]);
			leftControls.add(searchbox);
			leftControls.add(showSoldOut);
			leftControls.add(showNotSoldOut);
			leftControls.add(new JScrollPane(storeTextArea));
			
//			table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
//			
//			// Remove columns
//			while(table.getColumnCount() > 0)
//				table.removeColumn(table.getColumnModel().getColumn(0));
//			
//
//			table.setAutoCreateColumnsFromModel(false);
//			tableModel.addColumn("pORR");
			
//			String[] rownames = { "Name", "Type", "Penis", "Stock before", "To fridge", "From fridge", 
//					  			  "Stock after", "Buy price", "Sell price", "APK" };
//			for(int i = 0; i < rownames.length; i++)
//				tableModel.addColumn(rownames[i]);
//			
//			
//			
			class MyTableModel extends DefaultTableModel
			{
				private static final long serialVersionUID = -7736714281706932227L;
				
				@SuppressWarnings("unchecked")
				public Class getColumnClass(int c)
				{
					if(c == 4 || c == 5)
						return Integer.class;
					return super.getColumnClass(c);
				}
				
				public boolean isCellEditable(int row, int col)
				{
					//Note that the data/cell address is constant,
					//no matter where the cell appears onscreen.
					if(col == 4 || col == 5)
						return true;
					else
						return false;
				}
				
				public void setValueAt(Object value, int row, int col)
				{
					if(value == null)
						return;
					super.setValueAt(value, row, col);
					fireTableCellUpdated(row, col);
				}
			}
			
			
//			tableModel = new DefaultTableModel();
			tableModel = new MyTableModel();
			table = new JTable(tableModel);
			table.setAutoCreateRowSorter(true);
			table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			table.setRowSelectionAllowed(true);
			
			// Listener for entering data into the table
			tableModel.addTableModelListener(new TableModelListener()
			{
				public void tableChanged(TableModelEvent e)
				{
					int row = e.getFirstRow();
					int col = e.getColumn();
					if(row < 0 || (col != 4 && col != 5))
						return;
					TableModel model = (TableModel)e.getSource();
					int val = (Integer)model.getValueAt(row, col);
					
					
					BeerStock bs = (BeerStock)model.getValueAt(row, 0);
					
					double price  = bs.getBeer().getBuyprice();
					double newsum = new Double(val * price);
					if(col == 4)
					{
						minsum = wishsum - (bs.getMinAmount() * price) + newsum;	// Remove the old sum and add the new
						bs.setMinAmount(val);
					}
					else
					{
						wishsum = wishsum - (bs.getWishAmount() * price) + newsum;	// Remove the old sum and add the new
						bs.setWishAmount(val);
					}
					
					
					model.setValueAt(newsum, row, col + 2);
					updateSumLabel();
				}
			});
			
			
			// List Selection Model, for updating the box with info of the currently selected beers availability in
			// the stores.
			ListSelectionModel lsm = table.getSelectionModel();
			lsm.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e)
				{
					int row = table.getSelectedRow();
					if(row < 0)
						return;
					BeerStock bs = (BeerStock)table.getValueAt(row, 0);
					storeTextArea.setText(bs.getBeer().getStoresData());
					
					// Set the selection at the top, so that the most relevant stores can be seen without scrolling.
					storeTextArea.setSelectionStart(0);
					storeTextArea.setSelectionEnd(0);
			} });
			
			
			String[] rownames = { "Name", "In Stock", "Sold", "Price", "Min Amount", "Wish Amount", 
								  "Min Sum", "Wish Sum", "Stores" };
			for(int i = 0; i < rownames.length; i++)
				tableModel.addColumn(rownames[i]);
			
			table.getColumnModel().getColumn(0).setPreferredWidth(175);
			table.getColumnModel().getColumn(1).setPreferredWidth(25);
			table.getColumnModel().getColumn(2).setPreferredWidth(15);
			table.getColumnModel().getColumn(3).setPreferredWidth(15);
			table.getColumnModel().getColumn(4).setPreferredWidth(25);
			table.getColumnModel().getColumn(5).setPreferredWidth(25);
			table.getColumnModel().getColumn(6).setPreferredWidth(25);
			table.getColumnModel().getColumn(7).setPreferredWidth(25);
			
			JScrollPane jsc = new JScrollPane(table);
			table.setFillsViewportHeight(true);

			progressbar.setVisible(false);
			progressbar.setMinimum(0);
			
			
			Container right = new Container();
			right.setLayout(new BorderLayout());
			right.add(jsc, BorderLayout.CENTER);
			right.add(progressbar, BorderLayout.PAGE_END);
			right.add(sumlabel, BorderLayout.PAGE_END);
			
			area.add(right, BorderLayout.CENTER);
			area.add(leftControls, BorderLayout.WEST);
//			area.add(progressbar, BorderLayout.SOUTH);
			area.setVisible(true);								// Redraw the area now that it has new controls
		}
		
		
		private JButton[] createButtons()
		{
			String[] btnnames = { "Remove Selected Beers", "Remove Beers without ID", "Download store data", 
								  "Remove beers not in GBG", "Export List", "Close" };
			JButton[] btn = new JButton[btnnames.length];
			for(int i = 0; i < btn.length; i++)
				btn[i] = new JButton(btnnames[i]);
			
			
			Action delAction = new AbstractAction()
			{
				private static final long serialVersionUID = -197692976167946427L;
				public void actionPerformed(ActionEvent ae)
				{
System.out.println("Del");
					int[] rows = table.getSelectedRows();
					for(int i = 0; i < rows.length; i++)
						if(rows[i] != -1)
							removeBeer((pub.getIndex(((BeerStock)table.getValueAt(rows[i], 0)).getBeer().getName())));
					updateTableData();
				}
			};
			Action addAction = new AbstractAction()
			{
				private static final long serialVersionUID = -3381019543157339629L;
				public void actionPerformed(ActionEvent ae)
				{
					new EditDialog(null);
				}
			};
			Action homeAction = new AbstractAction()
			{
				private static final long serialVersionUID = 1148536792558547221L;
				public void actionPerformed(ActionEvent ae)
				{
System.out.println(":(");
					table.changeSelection(0, 0, false, false);
				}
			};
			Action endAction = new AbstractAction()
			{
				private static final long serialVersionUID = -2313325605379621827L;
				public void actionPerformed(ActionEvent ae)
				{
					table.changeSelection(table.getRowCount() - 1, 0, false, false);
				}
			};
			
			
			
/*			this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
					.put(KeyStroke.getKeyStroke("ENTER"), "edit");
			this.getRootPane().getActionMap().put("edit", editAction);
			this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
					.put(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.ALT_MASK), "add");
			this.getRootPane().getActionMap().put("add", addAction);
*/			
//			table.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
//				.put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE), "del");
//			table.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
//				.put(KeyStroke.getKeyStroke("DELETE"), "del");
//			table.getInputMap().put(KeyStroke.getKeyStroke("Delete"), "del");
//			table.getActionMap().put("del", delAction);
//			table.getInputMap().put(KeyStroke.getKeyStroke("HOME"), "home");
//			table.getActionMap().put("home", homeAction);
//			table.getInputMap().put(KeyStroke.getKeyStroke("END"), "end");
//			table.getActionMap().put("end", endAction);
//			table.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
//				.put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, InputEvent.CTRL_MASK), "del");
//			table.getActionMap().put("del", delAction);
//			table.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("HOME"), "home");
//			table.getActionMap().put("home", homeAction);
//			table.getInputMap().put(KeyStroke.getKeyStroke("END"), "end");
//			table.getActionMap().put("end", endAction);
			
			
			btn[0].addActionListener(delAction);
			btn[1].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae)
				{
					// We are to remove all beers with no ID. First get a list of IDs of the beers that are
					// to be removed, then let the user chose if some of them are actually to be kept.
					ArrayList<Integer> rems = new ArrayList<Integer>(180);	//There are 180 beers w/o ID as of 2011-02-08
					for(int i = 0; i < pub.size(); i++)
						if(pub.getBeer(i).getId() == -1)
							rems.add(i);
					
					showMassRemovalDlg(rems);
				}
			});
			btn[2].addActionListener(new ActionListener() {		// Download store data
				public void actionPerformed(ActionEvent ae)
				{
					sumlabel.setVisible(false);
					progressbar.setVisible(true);
					progressbar.setStringPainted(true);
					progressbar.setMaximum(pub.size() - 1);
					
					try
					{
						for(int i = 0; i < pub.size(); i++)
						{
							progressbar.setValue(i);
							pub.getBeer(i).setStores(PubIO.getStoreData(pub.getBeer(i).getId()));
						}
						
//						PubIO.removeFile("agent.xml");
//						PubIO.removeFile("bolaget.html");
					}
					catch(Exception e)
					{
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					
					progressbar.setVisible(false);
					sumlabel.setVisible(true);
					updateTableData();
				}
			});
			btn[3].addActionListener(new ActionListener()		// Remove beers not in GBG
			{
				public void actionPerformed(ActionEvent ae)
				{
					ArrayList<Integer> rems = new ArrayList<Integer>();
					
					for(int i = 0; i < pub.size(); i++)
						if(pub.getBeer(i).getStores() == null)
							rems.add(i);
					
					showMassRemovalDlg(rems);
				}
			});
			btn[4].addActionListener(new ActionListener()		// Export list
			{
				public void actionPerformed(ActionEvent ae)
				{
					try
					{
						PubIO.exportShopList(pub, new File("shoplist.html"));
					}
					catch(Exception e) {
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
			});
			btn[5].addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					area.setVisible(false);				// Hide in order to force a redraw (happens in initPubtools()).
					tableMode = MODE.NORMAL;
					pub = pubbackup;
					area.removeAll();
					initPubtools();
				}
			});
			
			return btn;
		}
		
		
		private void showMassRemovalDlg(ArrayList<Integer> rems)
		{
			// Create an array of Beer names
			String[] lst = new String[rems.size()];
			for(int i = 0; i < lst.length; i++)
				lst[i] = pub.getBeer(rems.get(i)).getName();
			
			
			// Create the list control and scrollbar for it
			JList list = new JList();
			list.setListData(lst);
			list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			JScrollPane jsp = new JScrollPane(list);
			
			
		    JLabel label_loginname = new JLabel("<html>The following beers are to be removed. <br />" +
		    		"If you want to keep any of them, select them here:</html>");
		    Object[] array = { label_loginname, jsp };
		    int res = JOptionPane.showConfirmDialog(null, array, "Do you wish to keep any beers?", 
		    						JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
			
		    
		    // If the user didn't press OK
		    if(res != JOptionPane.OK_OPTION)
		    	return;
		    
		    
		    int[] sels = list.getSelectedIndices();
			for(int i = sels.length - 1; i >= 0; i--)	// rems is the list of beers to delete. Remove the beers the 
				rems.remove(sels[i]);					// user wants to keep from the list
			for(int i = rems.size() - 1; i >= 0; i--)
				removeBeer(rems.get(i));				// Delete all beers that are to be removed.
			
			
			updateTableData();							// Don't forget to visually update the table.
		}
		
		private void removeBeer(int i)
		{
			minsum  -= pub.getBeer(i).getBuyprice() * pub.getBeerStock(i).getMinAmount();
			wishsum -= pub.getBeer(i).getBuyprice() * pub.getBeerStock(i).getWishAmount();
			pub.remove(i);
			updateSumLabel();
		}
		
		private void updateSumLabel()
		{
			sumlabel.setText("Min sum: " + PubIO.trimDecimals(minsum) + " kr. \tWish sum: " + 
							 PubIO.trimDecimals(wishsum) + " kr.");
			System.out.println("Min sum: " + minsum + " kr. \tWish sum: " + wishsum + " kr.");
		}
		
	}
	
	
	
	
	
	
	public class AboutDialog extends PubDialog
	{
		private static final long serialVersionUID = 2574520827367903166L;
		public AboutDialog()
		{
			JButton btn = new JButton("OK");
			btn.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae)	{ dispose();
			}});
			
			
			JPanel panel = new JPanel(new FlowLayout());
			try{
				panel.add(getImage("delta_logo.png"));
			} catch(NullPointerException e) { }
			panel.add(new JLabel("<html><h1><b><u>Pubtools 2.0</u></b></h1><br /><br />" +
					"Written by Jävla Johan 2010-2011<br />" +
					"Licensed under GPL 2.0 or newer.</html>"));
			
			getContentPane().add(panel, BorderLayout.CENTER);
			getContentPane().add(btn,   BorderLayout.PAGE_END);
			setTitle("About");
			pack();
			setVisible(true);
		}
		
		public JImagePanel getImage(String filename)
		{
			try
			{
				BufferedImage loadImg = ImageIO.read(new File(filename));
				this.setBounds(0, 0, loadImg.getWidth(), loadImg.getHeight());
				JImagePanel img = new JImagePanel(loadImg, 0, 0);
				img.setPreferredSize(new Dimension(loadImg.getWidth(), loadImg.getHeight()));
				return img;
			} catch(Exception e) { }
			return null;
		}
		
		private class JImagePanel extends JPanel
		{
			private static final long serialVersionUID = 2010019529178896016L;
			private BufferedImage image;
			private int x, y;
			
			public JImagePanel(BufferedImage image, int x, int y)
			{
				super();
				this.image = image;
				this.x = x;
				this.y = y;
			}
			
			protected void paintComponent(Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(image, x, y, null);
			}
		} 
	}
	
	public class HeaderDialog extends PubDialog
	{
		private static final long serialVersionUID = -1140294453898160494L;
		private PubTextField[] tfs;
		private JTextArea desc;
		
		public HeaderDialog()
		{
			JButton btn0 = new JButton("OK");
			btn0.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					try
					{
						String name = tfs[0].getText();
						int year    = Integer.parseInt(tfs[1].getText());
						int month   = Integer.parseInt(tfs[2].getText());
						int day     = Integer.parseInt(tfs[3].getText());
						String des  = desc.getText();
						
						pub.setName(name);
						pub.setDate(year, month, day);
						pub.setDescription(des);
						
						dispose();
					}
					catch(Exception e)
					{
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error on input data", 
							JOptionPane.ERROR_MESSAGE);
					}
				}
			});
			JButton btn1 = new JButton("Cancel");
			btn1.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					dispose();
				}
			});
			JButton btn2 = new JButton("Create new Pub");
			btn2.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					if(JOptionPane.showConfirmDialog(null,
							"This will create a new pub. What will happen is that \n" +
							"the amount that is in stock of each beer before a pub, \n" +
							"is overwritten by the amount that the old pub data has \n" +
							"specified as what's left after a pub. Remember to save \n" +
							"the old pub data file!\n\n" +
							"Do you want to create a new pub?",
							"Create a new pub?", JOptionPane.YES_NO_OPTION) == 0) // yes
					{
						Pub p = pub.clone();
						if(p == null)
							JOptionPane.showMessageDialog(null, "Could not clone the pub data", "Error", 
									JOptionPane.ERROR_MESSAGE);
						else
						{
							for(int i = 0; i < p.size(); i++)
							{
								BeerStock bs = p.getBeerStock(i);
								bs.setStockBefore(bs.getStockAfter());
							}
							
							pub = p;
							updateTableData();	// Update the table data. Otherwise we would still show the old
												// "before/after" data
						}
					}
				}
			});
			
			

			Container container = new Container();
			container.setLayout(new GridBagLayout());
			
			GridBagConstraints c0 = new GridBagConstraints();
			c0.fill = GridBagConstraints.HORIZONTAL;
			c0.weightx = 0.0;
			c0.gridwidth = 1;
			c0.gridy = 0;
			c0.gridx = 0;
			
			GridBagConstraints c1 = (GridBagConstraints)c0.clone();
			c1.gridwidth = 1;
			c1.weightx = 0.5;
			c1.gridx = 1;

			GridBagConstraints c2 = (GridBagConstraints)c1.clone();
			c2.gridwidth = 2;
			c2.weightx = 1.0;
			c2.gridx = 0;
			
			
			container.add(btn2, c2);
			c0.gridy += 1;
			c1.gridy += 1;
			
			
			String[] labels = { "Name:", "Year:", "Month:", "Day:", "Description / Comments:" };
			String[] values = { pub.getName(),  "" + pub.getYear(), "" + pub.getMonth(), 
												"" + pub.getDay(), pub.getDescription() };
			
			tfs = new PubTextField[4];
			for(int i = 0; i < 4; i++)
			{
				tfs[i] = new PubTextField(values[i]);
				
				container.add(new JLabel(labels[i]), c0);
				container.add(tfs[i], c1);
				c0.gridy += 1;
				c1.gridy += 1;
			}
			
			c2.gridy = c1.gridy;
			desc = new JTextArea(values[4]);
			desc.setRows(6);
			desc.setLineWrap(true);
			desc.setWrapStyleWord(true);
			container.add(new JLabel(labels[4]), c2);
			c2.gridy++;
			container.add(new JScrollPane(desc), c2);
			c0.gridy = c2.gridy + 1;
			c1.gridy = c2.gridy + 1;
			
			
			container.add(btn0, c0);
			container.add(btn1, c1);
			
			getContentPane().add(container, BorderLayout.CENTER);
			
			setTitle("Create new pub / Edit pub header");
			setSize(400, 270);
			setVisible(true);
		}
	}
}
